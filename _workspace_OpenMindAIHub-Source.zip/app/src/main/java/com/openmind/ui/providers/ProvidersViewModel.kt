package com.openmind.ui.providers

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.openmind.data.model.ProviderConfig
import com.openmind.data.repository.ProviderRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import javax.inject.Inject

data class ProvidersUiState(
    val providers: List<ProviderConfig> = emptyList(),
    val isTesting: Map<String, Boolean> = emptyMap(),
    val testResults: Map<String, Boolean> = emptyMap(),
    val isLoading: Boolean = false,
    val showAddDialog: Boolean = false,
    val showEditDialog: String? = null, // provider ID or null
    val error: String? = null
)

@HiltViewModel
class ProvidersViewModel @Inject constructor(
    private val providerRepository: ProviderRepository
) : ViewModel() {

    private val _uiState = MutableStateFlow(ProvidersUiState())
    val uiState: StateFlow<ProvidersUiState> = _uiState.asStateFlow()

    init {
        viewModelScope.launch {
            providerRepository.getAllProviders().collect { providers ->
                _uiState.update { it.copy(providers = providers, isLoading = false) }
            }
        }
        // Ensure default provider exists
        viewModelScope.launch {
            providerRepository.ensureDefaultProvider()
        }
    }

    fun addProvider(
        name: String,
        type: ProviderConfig.ProviderType,
        baseUrl: String,
        apiKey: String?,
        meta: String?
    ) {
        viewModelScope.launch {
            try {
                providerRepository.addProvider(name, type, baseUrl, apiKey, meta)
                _uiState.update { it.copy(showAddDialog = false) }
            } catch (e: Exception) {
                _uiState.update { it.copy(error = "Failed to add provider: ${e.message}") }
            }
        }
    }

    fun updateProvider(config: ProviderConfig) {
        viewModelScope.launch {
            try {
                providerRepository.updateProvider(config)
                _uiState.update { it.copy(showEditDialog = null) }
            } catch (e: Exception) {
                _uiState.update { it.copy(error = "Failed to update provider: ${e.message}") }
            }
        }
    }

    fun deleteProvider(id: String) {
        viewModelScope.launch {
            try {
                providerRepository.deleteProvider(id)
            } catch (e: Exception) {
                _uiState.update { it.copy(error = "Failed to delete provider: ${e.message}") }
            }
        }
    }

    fun toggleProvider(id: String, enabled: Boolean) {
        viewModelScope.launch {
            providerRepository.setProviderEnabled(id, enabled)
        }
    }

    fun setDefault(id: String) {
        viewModelScope.launch {
            providerRepository.setDefaultProvider(id)
        }
    }

    fun testConnection(id: String) {
        viewModelScope.launch {
            _uiState.update { it.copy(isTesting = it.isTesting + (id to true)) }
            val result = providerRepository.testConnection(id)
            _uiState.update { it.copy(
                isTesting = it.isTesting + (id to false),
                testResults = it.testResults + (id to result)
            )}
        }
    }

    fun showAddDialog() {
        _uiState.update { it.copy(showAddDialog = true) }
    }

    fun hideAddDialog() {
        _uiState.update { it.copy(showAddDialog = false) }
    }

    fun showEditDialog(id: String) {
        _uiState.update { it.copy(showEditDialog = id) }
    }

    fun hideEditDialog() {
        _uiState.update { it.copy(showEditDialog = null) }
    }

    fun clearError() {
        _uiState.update { it.copy(error = null) }
    }
}
