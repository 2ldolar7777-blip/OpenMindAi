package com.openmind.ui

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.core.splashscreen.SplashScreen.Companion.installSplashScreen
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.openmind.data.model.UserPreferences
import com.openmind.data.repository.PreferencesRepository
import com.openmind.ui.navigation.OpenMindNavHost
import com.openmind.ui.navigation.Routes
import com.openmind.ui.theme.OpenMindTheme
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.launch
import javax.inject.Inject

@AndroidEntryPoint
class MainActivity : ComponentActivity() {

    @Inject
    lateinit var preferencesRepository: PreferencesRepository

    override fun onCreate(savedInstanceState: Bundle?) {
        val splashScreen = installSplashScreen()
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        setContent {
            val preferences by preferencesRepository.preferences
                .collectAsState(initial = UserPreferences())

            OpenMindTheme(
                darkTheme = when (preferences.themeMode) {
                    UserPreferences.ThemeMode.LIGHT -> false
                    UserPreferences.ThemeMode.DARK -> true
                    UserPreferences.ThemeMode.SYSTEM -> null
                },
                dynamicColor = preferences.dynamicColor
            ) {
                OpenMindApp()
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun OpenMindApp() {
    val navController = rememberNavController()
    val navBackStackEntry by navController.currentBackStackEntryAsState()
    val currentRoute = navBackStackEntry?.destination?.route

    val showBottomBar = currentRoute in listOf(Routes.CONVERSATIONS)
    val showDrawer = currentRoute in listOf(Routes.CHAT, Routes.CHAT_WITH_ID, null)

    val drawerState = rememberDrawerState(initialValue = DrawerValue.Closed)
    val scope = rememberCoroutineScope()
    val snackbarHostState = remember { SnackbarHostState() }

    ModalNavigationDrawer(
        drawerContent = {
            ModalDrawerSheet {
                DrawerContent(
                    currentRoute = currentRoute,
                    onNavigate = { route ->
                        navController.navigate(route) {
                            launchSingleTop = true
                        }
                        scope.launch { drawerState.close() }
                    },
                    onCloseDrawer = {
                        scope.launch { drawerState.close() }
                    }
                )
            }
        },
        drawerState = drawerState,
        gesturesEnabled = showDrawer
    ) {
        Scaffold(
            snackbarHost = { SnackbarHost(snackbarHostState) },
            bottomBar = {
                if (showBottomBar) {
                    NavigationBar {
                        NavigationBarItem(
                            icon = { Icon(Icons.Default.Chat, contentDescription = null) },
                            selected = currentRoute == Routes.CONVERSATIONS,
                            onClick = {
                                navController.navigate(Routes.CONVERSATIONS) {
                                    popUpTo(Routes.CONVERSATIONS) { inclusive = true }
                                }
                            },
                            label = { Text("Chats") }
                        )
                        NavigationBarItem(
                            icon = { Icon(Icons.Default.Cloud, contentDescription = null) },
                            selected = currentRoute == Routes.PROVIDERS,
                            onClick = { navController.navigate(Routes.PROVIDERS) },
                            label = { Text("Providers") }
                        )
                        NavigationBarItem(
                            icon = { Icon(Icons.Default.Settings, contentDescription = null) },
                            selected = currentRoute == Routes.SETTINGS,
                            onClick = { navController.navigate(Routes.SETTINGS) },
                            label = { Text("Settings") }
                        )
                    }
                }
            }
        ) { paddingValues ->
            OpenMindNavHost(
                navController = navController,
                onToggleDrawer = {
                    scope.launch { drawerState.open() }
                }
            )
        }
    }
}

@Composable
private fun DrawerContent(
    currentRoute: String?,
    onNavigate: (String) -> Unit,
    onCloseDrawer: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        // App logo/header
        Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier.padding(vertical = 16.dp)
        ) {
            Icon(
                Icons.Default.SmartToy,
                contentDescription = null,
                modifier = Modifier.size(32.dp),
                tint = MaterialTheme.colorScheme.primary
            )
            Spacer(modifier = Modifier.width(12.dp))
            Text(
                text = "OpenMind AI Hub",
                style = MaterialTheme.typography.headlineSmall,
                color = MaterialTheme.colorScheme.primary
            )
        }

        HorizontalDivider()

        Spacer(modifier = Modifier.height(8.dp))

        // Navigation items
        DrawerItem(
            icon = Icons.Default.Chat,
            label = "Conversations",
            selected = currentRoute == Routes.CONVERSATIONS,
            onClick = { onNavigate(Routes.CONVERSATIONS) }
        )
        DrawerItem(
            icon = Icons.Default.Cloud,
            label = "AI Providers",
            selected = currentRoute == Routes.PROVIDERS,
            onClick = { onNavigate(Routes.PROVIDERS) }
        )
        DrawerItem(
            icon = Icons.Default.Settings,
            label = "Settings",
            selected = currentRoute == Routes.SETTINGS,
            onClick = { onNavigate(Routes.SETTINGS) }
        )

        Spacer(modifier = Modifier.height(16.dp))
        HorizontalDivider()
        Spacer(modifier = Modifier.height(8.dp))

        DrawerItem(
            icon = Icons.Default.Help,
            label = "Help & Feedback",
            selected = false,
            onClick = { /* TODO */ }
        )

        DrawerItem(
            icon = Icons.Default.Info,
            label = "About",
            selected = false,
            onClick = { /* TODO */ }
        )
    }
}

@Composable
private fun DrawerItem(
    icon: ImageVector,
    label: String,
    selected: Boolean,
    onClick: () -> Unit
) {
    val background = if (selected) {
        MaterialTheme.colorScheme.primaryContainer
    } else {
        MaterialTheme.colorScheme.surface
    }

    Surface(
        onClick = onClick,
        shape = MaterialTheme.shapes.medium,
        color = background
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                icon,
                contentDescription = null,
                tint = if (selected) MaterialTheme.colorScheme.onPrimaryContainer
                       else MaterialTheme.colorScheme.onSurfaceVariant
            )
            Spacer(modifier = Modifier.width(16.dp))
            Text(
                label,
                style = MaterialTheme.typography.bodyLarge,
                color = if (selected) MaterialTheme.colorScheme.onPrimaryContainer
                       else MaterialTheme.colorScheme.onSurface
            )
        }
    }
}
