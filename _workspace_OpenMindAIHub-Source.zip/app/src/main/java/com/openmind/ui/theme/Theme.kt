package com.openmind.ui.theme

import android.app.Activity
import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalView
import androidx.core.view.WindowCompat

// Custom color palette
private val LightColorScheme = lightColorScheme(
    primary = Color(0xFF1A73E8),
    onPrimary = Color.White,
    primaryContainer = Color(0xFFD3E3FD),
    onPrimaryContainer = Color(0xFF001C3A),
    secondary = Color(0xFF6750A4),
    onSecondary = Color.White,
    secondaryContainer = Color(0xFFEADDFF),
    onSecondaryContainer = Color(0xFF21005E),
    tertiary = Color(0xFF006C4C),
    onTertiary = Color.White,
    tertiaryContainer = Color(0xFF89F8C9),
    onTertiaryContainer = Color(0xFF002112),
    background = Color(0xFFFBFDFE),
    onBackground = Color(0xFF191C1E),
    surface = Color(0xFFFBFDFE),
    onSurface = Color(0xFF191C1E),
    surfaceVariant = Color(0xFFDDE3EB),
    onSurfaceVariant = Color(0xFF41484D),
    outline = Color(0xFF72787E),
    outlineVariant = Color(0xFFC2C8CE),
    inverseSurface = Color(0xFF2E3133),
    inverseOnSurface = Color(0xFFEFF1F3),
    inversePrimary = Color(0xFFA4C8FE),
    surfaceTint = Color(0xFF1A73E8),
    scrim = Color.Black,
)

private val DarkColorScheme = darkColorScheme(
    primary = Color(0xFFA4C8FE),
    onPrimary = Color(0xFF003060),
    primaryContainer = Color(0xFF004688),
    onPrimaryContainer = Color(0xFFD3E3FD),
    secondary = Color(0xFFCFBCFF),
    onSecondary = Color(0xFF381E72),
    secondaryContainer = Color(0xFF4F378B),
    onSecondaryContainer = Color(0xFFEADDFF),
    tertiary = Color(0xFF6CDBA9),
    onTertiary = Color(0xFF003826),
    tertiaryContainer = Color(0xFF005138),
    onTertiaryContainer = Color(0xFF89F8C9),
    background = Color(0xFF0F1315),
    onBackground = Color(0xFFE1E3E5),
    surface = Color(0xFF0F1315),
    onSurface = Color(0xFFE1E3E5),
    surfaceVariant = Color(0xFF41484D),
    onSurfaceVariant = Color(0xFFC2C8CE),
    outline = Color(0xFF8C9298),
    outlineVariant = Color(0xFF41484D),
    inverseSurface = Color(0xFFE1E3E5),
    inverseOnSurface = Color(0xFF2E3133),
    inversePrimary = Color(0xFF1A73E8),
    surfaceTint = Color(0xFFA4C8FE),
    scrim = Color.Black,
)

// Semantic colors for chat
data class ChatColors(
    val userBubbleColor: Color,
    val assistantBubbleColor: Color,
    val systemBubbleColor: Color,
    val userBubbleTextColor: Color,
    val assistantBubbleTextColor: Color,
    val codeBlockBackground: Color,
    val codeBlockTextColor: Color,
    val thinkingColor: Color,
    val errorColor: Color,
    val streamingCursorColor: Color
)

val LocalChatColors = compositionLocalOf {
    ChatColors(
        userBubbleColor = Color(0xFF1A73E8),
        assistantBubbleColor = Color(0xFFE8EAED),
        systemBubbleColor = Color(0xFFFFF3E0),
        userBubbleTextColor = Color.White,
        assistantBubbleTextColor = Color(0xFF1F1F1F),
        codeBlockBackground = Color(0xFF1E1E1E),
        codeBlockTextColor = Color(0xFFD4D4D4),
        thinkingColor = Color(0xFF9E9E9E),
        errorColor = Color(0xFFB3261E),
        streamingCursorColor = Color(0xFF1A73E8)
    )
}

@Composable
fun OpenMindTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    dynamicColor: Boolean = true,
    content: @Composable () -> Unit
) {
    val colorScheme = when {
        dynamicColor && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S -> {
            val context = LocalContext.current
            if (darkTheme) dynamicDarkColorScheme(context)
            else dynamicLightColorScheme(context)
        }
        darkTheme -> DarkColorScheme
        else -> LightColorScheme
    }

    val chatColors = if (darkTheme) {
        ChatColors(
            userBubbleColor = Color(0xFF1A73E8),
            assistantBubbleColor = Color(0xFF1E2024),
            systemBubbleColor = Color(0xFF3E2723),
            userBubbleTextColor = Color.White,
            assistantBubbleTextColor = Color(0xFFE1E3E5),
            codeBlockBackground = Color(0xFF0D1117),
            codeBlockTextColor = Color(0xFFC9D1D9),
            thinkingColor = Color(0xFF757575),
            errorColor = Color(0xFFF2B8B5),
            streamingCursorColor = Color(0xFFA4C8FE)
        )
    } else {
        ChatColors(
            userBubbleColor = Color(0xFF1A73E8),
            assistantBubbleColor = Color(0xFFF0F2F5),
            systemBubbleColor = Color(0xFFFFF8E1),
            userBubbleTextColor = Color.White,
            assistantBubbleTextColor = Color(0xFF1F1F1F),
            codeBlockBackground = Color(0xFF1E1E1E),
            codeBlockTextColor = Color(0xFFD4D4D4),
            thinkingColor = Color(0xFF9E9E9E),
            errorColor = Color(0xFFB3261E),
            streamingCursorColor = Color(0xFF1A73E8)
        )
    }

    CompositionLocalProvider(LocalChatColors provides chatColors) {
        MaterialTheme(
            colorScheme = colorScheme,
            typography = OpenMindTypography,
            content = content
        )
    }
}

// Edge-to-edge setup
@Composable
fun SetupEdgeToEdge() {
    val view = LocalView.current
    val darkTheme = isSystemInDarkTheme()
    
    SideEffect {
        val window = (view.context as Activity).window
        WindowCompat.setDecorFitsSystemWindows(window, false)
    }
}
