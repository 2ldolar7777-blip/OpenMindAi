package com.openmind.ui.navigation

import androidx.compose.animation.AnimatedContentTransitionScope
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.runtime.Composable
import androidx.navigation.NavHostController
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.navArgument
import com.openmind.ui.chat.ChatScreen
import com.openmind.ui.conversations.ConversationsScreen
import com.openmind.ui.providers.ProvidersScreen
import com.openmind.ui.settings.SettingsScreen

object Routes {
    const val CONVERSATIONS = "conversations"
    const val CHAT = "chat"
    const val CHAT_WITH_ID = "chat/{conversationId}"
    const val PROVIDERS = "providers"
    const val SETTINGS = "settings"

    fun chat(conversationId: String) = "chat/$conversationId"
}

@Composable
fun OpenMindNavHost(
    navController: NavHostController,
    onToggleDrawer: () -> Unit
) {
    NavHost(
        navController = navController,
        startDestination = Routes.CONVERSATIONS,
        enterTransition = fadeIn(animationSpec = tween(300)),
        exitTransition = fadeOut(animationSpec = tween(300))
    ) {
        composable(Routes.CONVERSATIONS) {
            ConversationsScreen(
                onConversationClick = { conversationId ->
                    navController.navigate(Routes.chat(conversationId))
                },
                onNewConversation = {
                    navController.navigate(Routes.CHAT)
                }
            )
        }

        composable(
            route = Routes.CHAT,
            enterTransition = {
                slideIntoContainer(
                    AnimatedContentTransitionScope.SlideDirection.Start,
                    animationSpec = tween(300)
                )
            },
            exitTransition = {
                slideOutOfContainer(
                    AnimatedContentTransitionScope.SlideDirection.End,
                    animationSpec = tween(300)
                )
            }
        ) {
            ChatScreen(
                onNavigateBack = { navController.popBackStack() },
                onToggleDrawer = onToggleDrawer
            )
        }

        composable(
            route = Routes.CHAT_WITH_ID,
            arguments = listOf(navArgument("conversationId") { type = NavType.StringType }),
            enterTransition = {
                slideIntoContainer(
                    AnimatedContentTransitionScope.SlideDirection.Start,
                    animationSpec = tween(300)
                )
            },
            exitTransition = {
                slideOutOfContainer(
                    AnimatedContentTransitionScope.SlideDirection.End,
                    animationSpec = tween(300)
                )
            }
        ) { backStackEntry ->
            val conversationId = backStackEntry.arguments?.getString("conversationId") ?: ""
            ChatScreen(
                conversationId = conversationId,
                onNavigateBack = { navController.popBackStack() },
                onToggleDrawer = onToggleDrawer
            )
        }

        composable(
            route = Routes.PROVIDERS,
            enterTransition = {
                slideIntoContainer(
                    AnimatedContentTransitionScope.SlideDirection.Up,
                    animationSpec = tween(300)
                )
            },
            exitTransition = {
                slideOutOfContainer(
                    AnimatedContentTransitionScope.SlideDirection.Down,
                    animationSpec = tween(300)
                )
            }
        ) {
            ProvidersScreen(
                onNavigateBack = { navController.popBackStack() }
            )
        }

        composable(
            route = Routes.SETTINGS,
            enterTransition = {
                slideIntoContainer(
                    AnimatedContentTransitionScope.SlideDirection.Up,
                    animationSpec = tween(300)
                )
            },
            exitTransition = {
                slideOutOfContainer(
                    AnimatedContentTransitionScope.SlideDirection.Down,
                    animationSpec = tween(300)
                )
            }
        ) {
            SettingsScreen(
                onNavigateBack = { navController.popBackStack() }
            )
        }
    }
}
