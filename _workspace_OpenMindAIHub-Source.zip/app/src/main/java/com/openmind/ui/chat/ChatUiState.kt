package com.openmind.ui.chat

import com.openmind.data.model.Message
import com.openmind.data.model.ModelInfo
import com.openmind.data.model.ProviderConfig

/**
 * UI state for the chat screen.
 */
data class ChatUiState(
    val messages: List<Message> = emptyList(),
    val currentConversationId: String? = null,
    val selectedProviderId: String? = null,
    val selectedModel: String? = null,
    val availableProviders: List<ProviderConfig> = emptyList(),
    val availableModels: List<ModelInfo> = emptyList(),
    val isLoading: Boolean = false,
    val isStreaming: Boolean = false,
    val isGenerating: Boolean = false,
    val streamingText: String = "",
    val error: String? = null,
    val inputText: String = "",
    val conversationTitle: String? = null
)
