package com.openmind.ui.conversations

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.openmind.data.model.Conversation
import com.openmind.data.repository.ChatRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import javax.inject.Inject

data class ConversationsUiState(
    val conversations: List<Conversation> = emptyList(),
    val searchQuery: String = "",
    val isSearching: Boolean = false,
    val selectedConversationId: String? = null
)

@HiltViewModel
class ConversationsViewModel @Inject constructor(
    private val chatRepository: ChatRepository
) : ViewModel() {

    private val _uiState = MutableStateFlow(ConversationsUiState())
    val uiState: StateFlow<ConversationsUiState> = _uiState.asStateFlow()

    init {
        viewModelScope.launch {
            chatRepository.getAllConversations().collect { conversations ->
                _uiState.update { it.copy(conversations = conversations) }
            }
        }
    }

    fun searchConversations(query: String) {
        _uiState.update { it.copy(searchQuery = query, isSearching = query.isNotBlank()) }
        if (query.isNotBlank()) {
            viewModelScope.launch {
                chatRepository.searchConversations(query).collect { results ->
                    _uiState.update { it.copy(conversations = results) }
                }
            }
        }
    }

    fun deleteConversation(id: String) {
        viewModelScope.launch {
            chatRepository.deleteConversation(id)
        }
    }

    fun pinConversation(id: String, pinned: Boolean) {
        viewModelScope.launch {
            chatRepository.setConversationPinned(id, pinned)
        }
    }

    fun selectConversation(id: String?) {
        _uiState.update { it.copy(selectedConversationId = id) }
    }

    fun createNewConversation(): String {
        var newId = ""
        viewModelScope.launch {
            val conversation = chatRepository.createConversation()
            newId = conversation.id
        }
        return newId
    }
}
