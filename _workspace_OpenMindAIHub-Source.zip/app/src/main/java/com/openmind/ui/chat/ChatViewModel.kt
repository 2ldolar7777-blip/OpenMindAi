package com.openmind.ui.chat

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.openmind.data.model.AIResponse
import com.openmind.data.model.Message
import com.openmind.data.model.ProviderConfig
import com.openmind.data.repository.ChatRepository
import com.openmind.data.repository.PreferencesRepository
import com.openmind.data.repository.ProviderRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class ChatViewModel @Inject constructor(
    private val chatRepository: ChatRepository,
    private val providerRepository: ProviderRepository,
    private val preferencesRepository: PreferencesRepository
) : ViewModel() {

    private val _uiState = MutableStateFlow(ChatUiState())
    val uiState: StateFlow<ChatUiState> = _uiState.asStateFlow()

    private var streamingJob: Job? = null

    init {
        // Load available providers
        viewModelScope.launch {
            providerRepository.getEnabledProviders().collect { providers ->
                _uiState.update { state ->
                    state.copy(
                        availableProviders = providers,
                        selectedProviderId = state.selectedProviderId
                            ?: providers.firstOrNull()?.id
                    )
                }
            }
        }

        // Load default provider from preferences
        viewModelScope.launch {
            preferencesRepository.preferences.collect { prefs ->
                _uiState.update { state ->
                    state.copy(
                        selectedProviderId = state.selectedProviderId ?: prefs.defaultProviderId,
                        selectedModel = state.selectedModel ?: prefs.defaultModel
                    )
                }
                // Load models for selected provider
                state.selectedProviderId?.let { loadModels(it) }
            }
        }
    }

    /**
     * Load/create a conversation.
     */
    fun loadConversation(conversationId: String) {
        viewModelScope.launch {
            val conversation = chatRepository.getConversation(conversationId) ?: return@launch
            _uiState.update { it.copy(
                currentConversationId = conversationId,
                conversationTitle = conversation.title,
                selectedProviderId = conversation.providerId ?: it.selectedProviderId,
                selectedModel = conversation.modelName ?: it.selectedModel
            )}

            // Load messages
            chatRepository.getMessages(conversationId).collect { messages ->
                _uiState.update { it.copy(messages = messages) }
            }
        }
    }

    /**
     * Create a new conversation.
     */
    fun createNewConversation() {
        viewModelScope.launch {
            val state = _uiState.value
            val conversation = chatRepository.createConversation(
                providerId = state.selectedProviderId,
                modelName = state.selectedModel
            )
            loadConversation(conversation.id)
        }
    }

    /**
     * Send a message to the AI.
     */
    fun sendMessage(prompt: String) {
        if (prompt.isBlank()) return

        val state = _uiState.value
        val conversationId = state.currentConversationId ?: run {
            // Create a new conversation if none exists
            viewModelScope.launch {
                val conversation = chatRepository.createConversation(
                    providerId = state.selectedProviderId,
                    modelName = state.selectedModel
                )
                _uiState.update { it.copy(currentConversationId = conversation.id) }
                performSendMessage(conversation.id, prompt)
            }
            return
        }

        performSendMessage(conversationId, prompt)
    }

    private fun performSendMessage(conversationId: String, prompt: String) {
        val state = _uiState.value

        _uiState.update { it.copy(
            isGenerating = true,
            streamingText = "",
            inputText = ""
        )}

        streamingJob = viewModelScope.launch {
            chatRepository.sendMessage(
                providerId = state.selectedProviderId ?: return@launch,
                conversationId = conversationId,
                prompt = prompt,
                model = state.selectedModel
            ).collect { part ->
                if (part.isFinal) {
                    _uiState.update { it.copy(
                        isGenerating = false,
                        streamingText = ""
                    )}
                } else {
                    _uiState.update { it.copy(
                        streamingText = it.streamingText + part.token
                    )}
                }
            }
        }
    }

    /**
     * Cancel ongoing generation.
     */
    fun cancelGeneration() {
        streamingJob?.cancel()
        streamingJob = null
        val state = _uiState.value
        state.selectedProviderId?.let {
            viewModelScope.launch {
                chatRepository.cancelGeneration(it)
            }
        }
        _uiState.update { it.copy(
            isGenerating = false,
            streamingText = ""
        )}
    }

    /**
     * Select a provider.
     */
    fun selectProvider(providerId: String) {
        _uiState.update { it.copy(
            selectedProviderId = providerId,
            selectedModel = null,
            availableModels = emptyList()
        )}
        loadModels(providerId)
    }

    /**
     * Select a model.
     */
    fun selectModel(modelId: String) {
        _uiState.update { it.copy(selectedModel = modelId) }
    }

    /**
     * Load models for a provider.
     */
    private fun loadModels(providerId: String) {
        viewModelScope.launch {
            val models = providerRepository.getModelsForProvider(providerId)
            _uiState.update { it.copy(availableModels = models) }
        }
    }

    /**
     * Delete a conversation.
     */
    fun deleteConversation(conversationId: String) {
        viewModelScope.launch {
            chatRepository.deleteConversation(conversationId)
            _uiState.update { it.copy(
                currentConversationId = null,
                messages = emptyList(),
                conversationTitle = null
            )}
        }
    }

    /**
     * Update input text.
     */
    fun updateInputText(text: String) {
        _uiState.update { it.copy(inputText = text) }
    }

    /**
     * Clear error.
     */
    fun clearError() {
        _uiState.update { it.copy(error = null) }
    }

    override fun onCleared() {
        super.onCleared()
        streamingJob?.cancel()
    }
}
