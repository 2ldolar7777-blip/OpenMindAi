package com.openmind.ui.settings

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.openmind.data.model.UserPreferences
import com.openmind.data.repository.PreferencesRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class SettingsViewModel @Inject constructor(
    private val preferencesRepository: PreferencesRepository
) : ViewModel() {

    val preferences: StateFlow<UserPreferences> = preferencesRepository.preferences
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), UserPreferences())

    fun updateThemeMode(mode: UserPreferences.ThemeMode) {
        viewModelScope.launch {
            preferencesRepository.updateThemeMode(mode)
        }
    }

    fun updateDynamicColor(enabled: Boolean) {
        viewModelScope.launch {
            preferencesRepository.updateDynamicColor(enabled)
        }
    }

    fun updateSendWithEnter(enabled: Boolean) {
        viewModelScope.launch {
            preferencesRepository.updateSendWithEnter(enabled)
        }
    }

    fun updateStreamResponses(enabled: Boolean) {
        viewModelScope.launch {
            preferencesRepository.updateStreamResponses(enabled)
        }
    }

    fun updateShowTokenCount(enabled: Boolean) {
        viewModelScope.launch {
            preferencesRepository.updateShowTokenCount(enabled)
        }
    }

    fun updateFontSize(size: UserPreferences.FontSize) {
        viewModelScope.launch {
            preferencesRepository.updateFontSize(size)
        }
    }

    fun updateLanguage(language: String) {
        viewModelScope.launch {
            preferencesRepository.updateLanguage(language)
        }
    }

    fun updateAutoTitle(enabled: Boolean) {
        viewModelScope.launch {
            preferencesRepository.updateAutoTitle(enabled)
        }
    }

    fun updateMaxContextMessages(count: Int) {
        viewModelScope.launch {
            preferencesRepository.updateMaxContextMessages(count)
        }
    }

    fun updateTemperature(temperature: Float) {
        viewModelScope.launch {
            preferencesRepository.updateTemperature(temperature)
        }
    }

    fun updateMaxTokens(tokens: Int) {
        viewModelScope.launch {
            preferencesRepository.updateMaxTokens(tokens)
        }
    }

    fun updateTopP(topP: Float) {
        viewModelScope.launch {
            preferencesRepository.updateTopP(topP)
        }
    }
}
