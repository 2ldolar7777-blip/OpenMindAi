package com.openmind.ui.chat

import androidx.compose.animation.animateContentSize
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.unit.dp
import com.openmind.data.model.Message
import com.openmind.ui.components.StreamingCursor
import com.openmind.ui.theme.LocalChatColors

/**
 * Composable for rendering a single chat message.
 * Supports user, assistant, and system messages with distinct styling.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ChatItemComposable(
    message: Message,
    isStreaming: Boolean = false,
    streamingText: String = "",
    modifier: Modifier = Modifier
) {
    val chatColors = LocalChatColors.current
    val clipboardManager = LocalClipboardManager.current

    val isUser = message.role == Message.Role.USER
    val isSystem = message.role == Message.Role.SYSTEM

    val displayContent = if (isStreaming) streamingText else message.content
    val bubbleColor = when (message.role) {
        Message.Role.USER -> chatColors.userBubbleColor
        Message.Role.ASSISTANT -> chatColors.assistantBubbleColor
        Message.Role.SYSTEM -> chatColors.systemBubbleColor
    }
    val textColor = when (message.role) {
        Message.Role.USER -> chatColors.userBubbleTextColor
        Message.Role.ASSISTANT -> chatColors.assistantBubbleTextColor
        Message.Role.SYSTEM -> Color(0xFF5D4037) // Brown for system
    }

    Column(
        modifier = modifier
            .fillMaxWidth()
            .padding(horizontal = 12.dp, vertical = 4.dp),
        horizontalAlignment = if (isUser) Alignment.End else Alignment.Start
    ) {
        // Role label
        Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier.padding(bottom = 4.dp, start = 4.dp, end = 4.dp)
        ) {
            Icon(
                imageVector = when (message.role) {
                    Message.Role.USER -> Icons.Default.Person
                    Message.Role.ASSISTANT -> Icons.Default.SmartToy
                    Message.Role.SYSTEM -> Icons.Default.Settings
                },
                contentDescription = null,
                modifier = Modifier.size(16.dp),
                tint = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.6f)
            )
            Spacer(modifier = Modifier.width(4.dp))
            Text(
                text = when (message.role) {
                    Message.Role.USER -> "You"
                    Message.Role.ASSISTANT -> "Assistant"
                    Message.Role.SYSTEM -> "System"
                },
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.6f)
            )
            message.modelName?.let { model ->
                Spacer(modifier = Modifier.width(4.dp))
                Surface(
                    shape = RoundedCornerShape(4.dp),
                    color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
                ) {
                    Text(
                        text = model,
                        style = MaterialTheme.typography.labelSmall,
                        modifier = Modifier.padding(horizontal = 4.dp, vertical = 1.dp),
                        color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.5f)
                    )
                }
            }
        }

        // Message bubble
        Surface(
            shape = RoundedCornerShape(
                topStart = if (isUser) 16.dp else 4.dp,
                topEnd = if (isUser) 4.dp else 16.dp,
                bottomStart = 16.dp,
                bottomEnd = 16.dp
            ),
            color = bubbleColor,
            tonalElevation = if (isUser) 0.dp else 1.dp,
            modifier = Modifier
                .widthIn(max = 340.dp)
                .animateContentSize()
        ) {
            Column(
                modifier = Modifier.padding(12.dp)
            ) {
                // Content with markdown-like rendering
                MessageContent(
                    content = displayContent,
                    textColor = textColor,
                    isStreaming = isStreaming
                )

                // Streaming cursor
                if (isStreaming) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        StreamingCursor()
                    }
                }
            }
        }

        // Action row (copy, regen, etc.)
        if (!isStreaming && displayContent.isNotBlank()) {
            Row(
                modifier = Modifier.padding(top = 4.dp, start = 4.dp, end = 4.dp),
                horizontalArrangement = if (isUser) Arrangement.End else Arrangement.Start
            ) {
                // Copy button
                IconButton(
                    onClick = { clipboardManager.setText(AnnotatedString(displayContent)) },
                    modifier = Modifier.size(28.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.ContentCopy,
                        contentDescription = "Copy",
                        modifier = Modifier.size(14.dp),
                        tint = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.4f)
                    )
                }

                // Select text
                IconButton(
                    onClick = { /* TODO: Text selection mode */ },
                    modifier = Modifier.size(28.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.TextSelectStart,
                        contentDescription = "Select",
                        modifier = Modifier.size(14.dp),
                        tint = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.4f)
                    )
                }
            }
        }
    }
}

/**
 * Renders message content with basic markdown support.
 * Handles code blocks, bold, italic, headers, and lists.
 */
@Composable
private fun MessageContent(
    content: String,
    textColor: Color,
    isStreaming: Boolean
) {
    val chatColors = LocalChatColors.current
    val lines = content.split("\n")
    var inCodeBlock = false
    val codeBlockContent = mutableListOf<String>()

    Column {
        lines.forEachIndexed { index, line ->
            if (line.trimStart().startsWith("```") && !inCodeBlock) {
                inCodeBlock = true
                return@forEachIndexed
            } else if (line.trimStart().startsWith("```") && inCodeBlock) {
                // End code block
                inCodeBlock = false
                CodeBlock(codeBlockContent.joinToString("\n"))
                codeBlockContent.clear()
                return@forEachIndexed
            }

            if (inCodeBlock) {
                codeBlockContent.add(line)
                return@forEachIndexed
            }

            // Regular line rendering
            when {
                line.startsWith("### ") -> {
                    Text(
                        text = line.removePrefix("### "),
                        style = MaterialTheme.typography.titleSmall,
                        color = textColor,
                        fontWeight = FontWeight.SemiBold,
                        modifier = Modifier.padding(top = 8.dp, bottom = 4.dp)
                    )
                }
                line.startsWith("## ") -> {
                    Text(
                        text = line.removePrefix("## "),
                        style = MaterialTheme.typography.titleMedium,
                        color = textColor,
                        fontWeight = FontWeight.SemiBold,
                        modifier = Modifier.padding(top = 12.dp, bottom = 4.dp)
                    )
                }
                line.startsWith("# ") -> {
                    Text(
                        text = line.removePrefix("# "),
                        style = MaterialTheme.typography.titleLarge,
                        color = textColor,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(top = 16.dp, bottom = 8.dp)
                    )
                }
                line.startsWith("- ") || line.startsWith("* ") -> {
                    Row(modifier = Modifier.padding(start = 8.dp)) {
                        Text(
                            text = "•",
                            color = textColor,
                            style = MaterialTheme.typography.bodyMedium
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        FormattedText(
                            text = line.removePrefix("- ").removePrefix("* "),
                            textColor = textColor
                        )
                    }
                }
                line.trim().matches(Regex("^\\d+\\.\\s.*")) -> {
                    val num = line.trim().substringBefore(".")
                    val text = line.trim().substringAfter(". ")
                    Row(modifier = Modifier.padding(start = 8.dp)) {
                        Text(
                            text = "$num.",
                            color = textColor,
                            style = MaterialTheme.typography.bodyMedium,
                            fontWeight = FontWeight.Medium
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        FormattedText(text = text, textColor = textColor)
                    }
                }
                line.startsWith("> ") -> {
                    Surface(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(start = 8.dp, top = 4.dp, bottom = 4.dp),
                        shape = RoundedCornerShape(4.dp),
                        color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.3f)
                    ) {
                        Text(
                            text = line.removePrefix("> "),
                            style = MaterialTheme.typography.bodyMedium.copy(
                                fontFamily = FontFamily.Serif
                            ),
                            color = textColor.copy(alpha = 0.8f),
                            modifier = Modifier.padding(8.dp)
                        )
                    }
                }
                line.startsWith("---") || line.startsWith("***") -> {
                    HorizontalDivider(
                        modifier = Modifier.padding(vertical = 8.dp),
                        color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.3f)
                    )
                }
                line.isBlank() -> {
                    Spacer(modifier = Modifier.height(4.dp))
                }
                else -> {
                    FormattedText(text = line, textColor = textColor)
                }
            }
        }

        // If still in code block at end of content
        if (inCodeBlock && codeBlockContent.isNotEmpty()) {
            CodeBlock(codeBlockContent.joinToString("\n"))
        }
    }
}

/**
 * Code block with syntax-highlighted background.
 */
@Composable
private fun CodeBlock(code: String) {
    val chatColors = LocalChatColors.current
    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp),
        shape = RoundedCornerShape(8.dp),
        color = chatColors.codeBlockBackground
    ) {
        Column {
            // Copy button header
            val clipboardManager = LocalClipboardManager.current
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(chatColors.codeBlockBackground.copy(alpha = 0.8f))
                    .padding(horizontal = 8.dp, vertical = 4.dp),
                horizontalArrangement = Arrangement.End
            ) {
                IconButton(
                    onClick = { clipboardManager.setText(AnnotatedString(code)) },
                    modifier = Modifier.size(24.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.ContentCopy,
                        contentDescription = "Copy code",
                        modifier = Modifier.size(12.dp),
                        tint = Color.White.copy(alpha = 0.5f)
                    )
                }
            }
            
            Text(
                text = code,
                fontFamily = FontFamily.Monospace,
                color = chatColors.codeBlockTextColor,
                style = MaterialTheme.typography.bodySmall,
                modifier = Modifier
                    .horizontalScroll(rememberScrollState())
                    .padding(12.dp)
            )
        }
    }
}

/**
 * Text with basic inline formatting (bold, italic, code).
 */
@Composable
private fun FormattedText(
    text: String,
    textColor: Color,
    modifier: Modifier = Modifier
) {
    // Simple approach: detect inline code and render differently
    val annotatedText = buildAnnotatedString(text, textColor)
    
    Text(
        text = annotatedText,
        color = textColor,
        style = MaterialTheme.typography.bodyMedium,
        modifier = modifier.padding(bottom = 2.dp)
    )
}

@Composable
private fun buildAnnotatedString(text: String, baseColor: Color): AnnotatedString {
    // Build annotated string with inline formatting
    val builder = androidx.compose.ui.text.AnnotatedString.Builder()
    var remaining = text
    
    while (remaining.isNotEmpty()) {
        // Find inline code
        val codeStart = remaining.indexOf("`")
        val boldStart = remaining.indexOf("**")
        val italicStart = remaining.indexOf("*")
        
        when {
            codeStart >= 0 && (boldStart < 0 || codeStart < boldStart) -> {
                // Add text before code
                builder.append(remaining.substring(0, codeStart))
                val afterCodeMarker = remaining.substring(codeStart + 1)
                val codeEnd = afterCodeMarker.indexOf("`")
                if (codeEnd >= 0) {
                    val codeText = afterCodeMarker.substring(0, codeEnd)
                    builder.pushStyle(androidx.compose.ui.text.SpanStyle(
                        fontFamily = FontFamily.Monospace,
                        background = baseColor.copy(alpha = 0.1f)
                    ))
                    builder.append(codeText)
                    builder.pop()
                    remaining = afterCodeMarker.substring(codeEnd + 1)
                } else {
                    builder.append(remaining.substring(codeStart))
                    remaining = ""
                }
            }
            else -> {
                builder.append(remaining)
                remaining = ""
            }
        }
    }
    
    return builder.toAnnotatedString()
}
