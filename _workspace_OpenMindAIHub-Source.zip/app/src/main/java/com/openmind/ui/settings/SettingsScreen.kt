package com.openmind.ui.settings

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.input.nestedscroll.nestedScroll
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import com.openmind.data.model.UserPreferences

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(
    onNavigateBack: () -> Unit,
    viewModel: SettingsViewModel = hiltViewModel()
) {
    val preferences by viewModel.preferences.collectAsState()
    val scrollBehavior = TopAppBarDefaults.pinnedScrollBehavior()

    Scaffold(
        modifier = Modifier.nestedScroll(scrollBehavior.nestedScrollConnection),
        topBar = {
            TopAppBar(
                title = { Text("Settings") },
                navigationIcon = {
                    IconButton(onClick = onNavigateBack) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Back")
                    }
                },
                scrollBehavior = scrollBehavior
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            // Appearance Section
            SettingsSectionHeader("Appearance")

            // Theme
            var showThemeDialog by remember { mutableStateOf(false) }
            SettingsItem(
                icon = Icons.Default.Palette,
                title = "Theme",
                subtitle = when (preferences.themeMode) {
                    UserPreferences.ThemeMode.LIGHT -> "Light"
                    UserPreferences.ThemeMode.DARK -> "Dark"
                    UserPreferences.ThemeMode.SYSTEM -> "System"
                },
                onClick = { showThemeDialog = true }
            )

            if (showThemeDialog) {
                AlertDialog(
                    onDismissRequest = { showThemeDialog = false },
                    title = { Text("Choose Theme") },
                    text = {
                        Column {
                            UserPreferences.ThemeMode.entries.forEach { mode ->
                                Row(
                                    modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),
                                    vertical = androidx.compose.ui.Alignment.CenterVertically
                                ) {
                                    RadioButton(
                                        selected = preferences.themeMode == mode,
                                        onClick = { viewModel.updateThemeMode(mode) }
                                    )
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text(mode.name)
                                }
                            }
                        }
                    },
                    confirmButton = {
                        TextButton(onClick = { showThemeDialog = false }) { Text("OK") }
                    }
                )
            }

            // Dynamic Color
            SettingsSwitch(
                icon = Icons.Default.ColorLens,
                title = "Dynamic Color",
                subtitle = "Use system wallpaper colors",
                checked = preferences.dynamicColor,
                onCheckedChange = { viewModel.updateDynamicColor(it) }
            )

            // Font Size
            var showFontDialog by remember { mutableStateOf(false) }
            SettingsItem(
                icon = Icons.Default.TextFields,
                title = "Font Size",
                subtitle = preferences.fontSize.name,
                onClick = { showFontDialog = true }
            )

            if (showFontDialog) {
                AlertDialog(
                    onDismissRequest = { showFontDialog = false },
                    title = { Text("Font Size") },
                    text = {
                        Column {
                            UserPreferences.FontSize.entries.forEach { size ->
                                Row(
                                    modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),
                                    vertical = androidx.compose.ui.Alignment.CenterVertically
                                ) {
                                    RadioButton(
                                        selected = preferences.fontSize == size,
                                        onClick = { viewModel.updateFontSize(size) }
                                    )
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text(size.name)
                                }
                            }
                        }
                    },
                    confirmButton = { TextButton(onClick = { showFontDialog = false }) { Text("OK") } }
                )
            }

            HorizontalDivider(modifier = Modifier.padding(vertical = 8.dp))

            // Chat Section
            SettingsSectionHeader("Chat")

            SettingsSwitch(
                icon = Icons.Default.Send,
                title = "Send with Enter",
                subtitle = "Press Enter to send messages",
                checked = preferences.sendWithEnter,
                onCheckedChange = { viewModel.updateSendWithEnter(it) }
            )

            SettingsSwitch(
                icon = Icons.Default.Stream,
                title = "Stream Responses",
                subtitle = "Show tokens as they arrive",
                checked = preferences.streamResponses,
                onCheckedChange = { viewModel.updateStreamResponses(it) }
            )

            SettingsSwitch(
                icon = Icons.Default.Numbers,
                title = "Show Token Count",
                subtitle = "Display token usage per message",
                checked = preferences.showTokenCount,
                onCheckedChange = { viewModel.updateShowTokenCount(it) }
            )

            SettingsSwitch(
                icon = Icons.Default.Title,
                title = "Auto-generate Titles",
                subtitle = "Automatically name conversations",
                checked = preferences.autoTitle,
                onCheckedChange = { viewModel.updateAutoTitle(it) }
            )

            HorizontalDivider(modifier = Modifier.padding(vertical = 8.dp))

            // Model Parameters
            SettingsSectionHeader("Model Parameters")

            // Temperature Slider
            Column(modifier = Modifier.fillMaxWidth()) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text("Temperature", style = MaterialTheme.typography.bodyMedium)
                    Text(String.format("%.1f", preferences.temperature),
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.primary)
                }
                Slider(
                    value = preferences.temperature,
                    onValueChange = { viewModel.updateTemperature(it) },
                    valueRange = 0f..2f,
                    steps = 20
                )
            }

            // Max Tokens
            Column(modifier = Modifier.fillMaxWidth()) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text("Max Tokens", style = MaterialTheme.typography.bodyMedium)
                    Text(preferences.maxTokens.toString(),
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.primary)
                }
                Slider(
                    value = preferences.maxTokens.toFloat(),
                    onValueChange = { viewModel.updateMaxTokens(it.toInt()) },
                    valueRange = 256f..8192f,
                    steps = 30
                )
            }

            // Context Messages
            Column(modifier = Modifier.fillMaxWidth()) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text("Context Messages", style = MaterialTheme.typography.bodyMedium)
                    Text(preferences.maxContextMessages.toString(),
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.primary)
                }
                Slider(
                    value = preferences.maxContextMessages.toFloat(),
                    onValueChange = { viewModel.updateMaxContextMessages(it.toInt()) },
                    valueRange = 5f..50f,
                    steps = 9
                )
            }

            HorizontalDivider(modifier = Modifier.padding(vertical = 8.dp))

            // About Section
            SettingsSectionHeader("About")

            SettingsItem(
                icon = Icons.Default.Info,
                title = "Version",
                subtitle = "1.0.0",
                onClick = { }
            )

            SettingsItem(
                icon = Icons.Default.Source,
                title = "Open Source Licenses",
                subtitle = "View third-party licenses",
                onClick = { }
            )

            Spacer(modifier = Modifier.height(32.dp))
        }
    }
}

@Composable
private fun SettingsSectionHeader(title: String) {
    Text(
        text = title,
        style = MaterialTheme.typography.titleSmall,
        color = MaterialTheme.colorScheme.primary,
        modifier = Modifier.padding(top = 8.dp, bottom = 4.dp)
    )
}

@Composable
private fun SettingsItem(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    title: String,
    subtitle: String,
    onClick: () -> Unit
) {
    Surface(onClick = onClick, shape = MaterialTheme.shapes.medium) {
        Row(
            modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp),
            vertical = androidx.compose.ui.Alignment.CenterVertically
        ) {
            Icon(icon, contentDescription = null, tint = MaterialTheme.colorScheme.onSurfaceVariant)
            Spacer(modifier = Modifier.width(16.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(title, style = MaterialTheme.typography.bodyLarge)
                Text(subtitle, style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            Icon(Icons.Default.ChevronRight, contentDescription = null,
                tint = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.3f))
        }
    }
}

@Composable
private fun SettingsSwitch(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    title: String,
    subtitle: String,
    checked: Boolean,
    onCheckedChange: (Boolean) -> Unit
) {
    Row(
        modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),
        vertical = androidx.compose.ui.Alignment.CenterVertically
    ) {
        Icon(icon, contentDescription = null, tint = MaterialTheme.colorScheme.onSurfaceVariant)
        Spacer(modifier = Modifier.width(16.dp))
        Column(modifier = Modifier.weight(1f)) {
            Text(title, style = MaterialTheme.typography.bodyLarge)
            Text(subtitle, style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        Switch(checked = checked, onCheckedChange = onCheckedChange)
    }
}
