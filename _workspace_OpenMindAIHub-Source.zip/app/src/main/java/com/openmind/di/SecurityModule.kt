package com.openmind.di

import android.content.Context
import com.openmind.data.security.SecureKeyStore
import com.openmind.data.voice.VoiceInputManager
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.qualifiers.ApplicationContext
import dagger.hilt.components.SingletonComponent
import javax.inject.Singleton

/**
 * Hilt module for security and utility providers.
 */
@Module
@InstallIn(SingletonComponent::class)
object SecurityModule {

    @Provides
    @Singleton
    fun provideSecureKeyStore(@ApplicationContext context: Context): SecureKeyStore {
        return SecureKeyStore(context)
    }

    @Provides
    fun provideVoiceInputManager(@ApplicationContext context: Context): VoiceInputManager {
        return VoiceInputManager(context)
    }
}
