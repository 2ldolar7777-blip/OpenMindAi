package com.openmind.di

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.preferencesDataStore
import com.openmind.data.db.ProviderConfigDao
import com.openmind.data.provider.ProviderManager
import com.openmind.data.repository.ChatRepository
import com.openmind.data.repository.PreferencesRepository
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.qualifiers.ApplicationContext
import dagger.hilt.components.SingletonComponent
import javax.inject.Singleton

@Module
@InstallIn(SingletonComponent::class)
object ProviderModule {

    private val Context.dataStore: DataStore<Preferences> by preferencesDataStore(name = "openmind_preferences")

    @Provides
    @Singleton
    fun provideDataStore(
        @ApplicationContext context: Context
    ): DataStore<Preferences> = context.dataStore

    @Provides
    @Singleton
    fun providePreferencesRepository(
        dataStore: DataStore<Preferences>
    ): PreferencesRepository = PreferencesRepository(dataStore)

    @Provides
    @Singleton
    fun provideChatRepository(
        providerManager: ProviderManager,
        conversationDao: com.openmind.data.db.ConversationDao,
        messageDao: com.openmind.data.db.MessageDao
    ): ChatRepository = ChatRepository(providerManager, conversationDao, messageDao)
}
