package com.openmind.di

import android.content.Context
import androidx.room.Room
import com.openmind.data.db.*
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.qualifiers.ApplicationContext
import dagger.hilt.components.SingletonComponent
import javax.inject.Singleton

@Module
@InstallIn(SingletonComponent::class)
object DatabaseModule {

    @Provides
    @Singleton
    fun provideDatabase(
        @ApplicationContext context: Context
    ): OpenMindDatabase {
        return Room.databaseBuilder(
            context,
            OpenMindDatabase::class.java,
            OpenMindDatabase.DATABASE_NAME
        )
            .addTypeConverters(Converters())
            .fallbackToDestructiveMigration()
            .setJournalMode(RoomDatabase.JournalMode.AUTOMATIC)
            .build()
    }

    @Provides
    fun provideConversationDao(database: OpenMindDatabase): ConversationDao =
        database.conversationDao()

    @Provides
    fun provideMessageDao(database: OpenMindDatabase): MessageDao =
        database.messageDao()

    @Provides
    fun provideProviderConfigDao(database: OpenMindDatabase): ProviderConfigDao =
        database.providerConfigDao()
}
