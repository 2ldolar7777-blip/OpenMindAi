package com.openmind.data.security

import android.content.Context
import android.content.SharedPreferences
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey
import dagger.hilt.android.qualifiers.ApplicationContext
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Secure storage for API keys and sensitive configuration using EncryptedSharedPreferences.
 *
 * Uses AndroidX Security library with AES256_GCM encryption for values and
 * AES256_SIV for keys. The master key is stored in the Android Keystore
 * and is bound to the app's signing key on Android 6+.
 *
 * Fallback strategy: On devices where EncryptedSharedPreferences fails
 * (e.g., corrupted master key after backup restore), falls back to
 * regular SharedPreferences with a warning logged.
 */
@Singleton
class SecureKeyStore @Inject constructor(
    @ApplicationContext private val context: Context
) {
    private val masterKey: MasterKey by lazy {
        MasterKey.Builder(context)
            .setKeyScheme(MasterKey.KeyScheme.AES256_GCM)
            .build()
    }

    private val encryptedPrefs: SharedPreferences by lazy {
        try {
            EncryptedSharedPreferences.create(
                context,
                SECURE_PREFS_FILE,
                masterKey,
                EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
                EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
            )
        } catch (e: Exception) {
            // Fallback: if encrypted prefs fail (e.g., after backup restore),
            // create a new instance by deleting the corrupted file
            try {
                context.deleteSharedPreferences(SECURE_PREFS_FILE)
                EncryptedSharedPreferences.create(
                    context,
                    SECURE_PREFS_FILE,
                    masterKey,
                    EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
                    EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
                )
            } catch (e2: Exception) {
                // Last resort: use plain SharedPreferences (better than crashing)
                android.util.Log.w(TAG, "EncryptedSharedPreferences unavailable, using fallback")
                context.getSharedPreferences(SECURE_PREFS_FILE_FALLBACK, Context.MODE_PRIVATE)
            }
        }
    }

    /**
     * Store an API key securely for a given provider.
     * @param providerId The unique identifier of the provider
     * @param apiKey The API key to store (will be encrypted at rest)
     */
    fun storeApiKey(providerId: String, apiKey: String) {
        encryptedPrefs.edit()
            .putString(keyForProvider(providerId), apiKey)
            .apply()
    }

    /**
     * Retrieve the stored API key for a provider.
     * @param providerId The unique identifier of the provider
     * @return The decrypted API key, or null if not stored
     */
    fun getApiKey(providerId: String): String? {
        return encryptedPrefs.getString(keyForProvider(providerId), null)
    }

    /**
     * Remove the stored API key for a provider.
     * @param providerId The unique identifier of the provider
     */
    fun removeApiKey(providerId: String) {
        encryptedPrefs.edit()
            .remove(keyForProvider(providerId))
            .apply()
    }

    /**
     * Check if an API key exists for a provider.
     */
    fun hasApiKey(providerId: String): Boolean {
        return encryptedPrefs.contains(keyForProvider(providerId))
    }

    /**
     * Store a generic secret value securely.
     */
    fun storeSecret(key: String, value: String) {
        encryptedPrefs.edit()
            .putString(key, value)
            .apply()
    }

    /**
     * Retrieve a generic secret value.
     */
    fun getSecret(key: String): String? {
        return encryptedPrefs.getString(key, null)
    }

    /**
     * Remove a generic secret.
     */
    fun removeSecret(key: String) {
        encryptedPrefs.edit()
            .remove(key)
            .apply()
    }

    /**
     * Clear all stored secrets (e.g., on logout).
     */
    fun clearAll() {
        encryptedPrefs.edit().clear().apply()
    }

    /**
     * Mask an API key for display purposes.
     * Shows first 4 and last 4 characters, masks the rest.
     * e.g., "sk-1234567890abcdef" → "sk-1•••••••cdef"
     */
    fun maskApiKey(apiKey: String): String {
        if (apiKey.length <= 8) return "••••••••"
        val first = apiKey.take(4)
        val last = apiKey.takeLast(4)
        val masked = "•".repeat(apiKey.length - 8)
        return "$first$masked$last"
    }

    private fun keyForProvider(providerId: String): String = "api_key_$providerId"

    companion object {
        private const val TAG = "SecureKeyStore"
        private const val SECURE_PREFS_FILE = "openmind_secure_keys"
        private const val SECURE_PREFS_FILE_FALLBACK = "openmind_secure_keys_fallback"
    }
}
