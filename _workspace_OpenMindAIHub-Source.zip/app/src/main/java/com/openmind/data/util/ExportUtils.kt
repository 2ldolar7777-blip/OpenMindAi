package com.openmind.data.util

import com.openmind.data.model.Conversation
import com.openmind.data.model.Message
import kotlinx.serialization.Serializable
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json

/**
 * Export and import utilities for conversations.
 * Supports JSON and Markdown export formats.
 */
object ExportUtils {

    private val json = Json {
        prettyPrint = true
        ignoreUnknownKeys = true
        encodeDefaults = true
    }

    /**
     * Export format types.
     */
    enum class ExportFormat {
        JSON, MARKDOWN, PLAIN_TEXT
    }

    /**
     * Serializable wrapper for exporting a conversation with its messages.
     */
    @Serializable
    data class ExportedConversation(
        val conversation: ConversationData,
        val messages: List<MessageData>,
        val exportedAt: Long = System.currentTimeMillis(),
        val version: Int = 1
    )

    @Serializable
    data class ConversationData(
        val id: String,
        val title: String,
        val providerId: String,
        val modelName: String,
        val systemPrompt: String?,
        val isPinned: Boolean,
        val tags: List<String>,
        val createdAt: Long,
        val updatedAt: Long
    )

    @Serializable
    data class MessageData(
        val id: String,
        val role: String,
        val content: String,
        val timestamp: Long,
        val tokenCount: Int?
    )

    /**
     * Export a conversation with messages to JSON format.
     */
    fun exportToJson(conversation: Conversation, messages: List<Message>): String {
        val exported = ExportedConversation(
            conversation = ConversationData(
                id = conversation.id,
                title = conversation.title,
                providerId = conversation.providerId,
                modelName = conversation.modelName,
                systemPrompt = conversation.systemPrompt,
                isPinned = conversation.isPinned,
                tags = conversation.tags,
                createdAt = conversation.createdAt,
                updatedAt = conversation.updatedAt
            ),
            messages = messages.map { msg ->
                MessageData(
                    id = msg.id,
                    role = msg.role.name,
                    content = msg.content,
                    timestamp = msg.timestamp,
                    tokenCount = msg.tokenCount
                )
            }
        )
        return json.encodeToString(exported)
    }

    /**
     * Export a conversation with messages to Markdown format.
     */
    fun exportToMarkdown(conversation: Conversation, messages: List<Message>): String {
        val sb = StringBuilder()
        sb.appendLine("# ${conversation.title}")
        sb.appendLine()
        sb.appendLine("> Model: ${conversation.modelName} | Provider: ${conversation.providerId}")
        sb.appendLine("> Exported: ${DateTimeUtils.formatFullDateTime(System.currentTimeMillis())}")
        sb.appendLine()

        if (conversation.systemPrompt != null) {
            sb.appendLine("## System Prompt")
            sb.appendLine()
            sb.appendLine("> ${conversation.systemPrompt}")
            sb.appendLine()
        }

        sb.appendLine("---")
        sb.appendLine()

        messages.forEach { msg ->
            when (msg.role) {
                Message.Role.USER -> {
                    sb.appendLine("### 👤 User")
                    sb.appendLine()
                    sb.appendLine(msg.content)
                    sb.appendLine()
                }
                Message.Role.ASSISTANT -> {
                    sb.appendLine("### 🤖 Assistant")
                    sb.appendLine()
                    sb.appendLine(msg.content)
                    sb.appendLine()
                }
                Message.Role.SYSTEM -> {
                    sb.appendLine("### ⚙️ System")
                    sb.appendLine()
                    sb.appendLine(msg.content)
                    sb.appendLine()
                }
            }
            sb.appendLine("---")
            sb.appendLine()
        }

        return sb.toString()
    }

    /**
     * Export a conversation to plain text format.
     */
    fun exportToPlainText(conversation: Conversation, messages: List<Message>): String {
        val sb = StringBuilder()
        sb.appendLine("${conversation.title}")
        sb.appendLine("Model: ${conversation.modelName}")
        sb.appendLine()

        messages.forEach { msg ->
            val roleLabel = when (msg.role) {
                Message.Role.USER -> "User"
                Message.Role.ASSISTANT -> "Assistant"
                Message.Role.SYSTEM -> "System"
            }
            sb.appendLine("[$roleLabel]: ${msg.content}")
            sb.appendLine()
        }

        return sb.toString()
    }

    /**
     * Import a conversation from JSON format.
     * @throws IllegalArgumentException if the JSON is invalid
     */
    fun importFromJson(jsonString: String): Pair<Conversation, List<Message>> {
        val exported = json.decodeFromString<ExportedConversation>(jsonString)
        val conversation = Conversation(
            id = exported.conversation.id,
            title = exported.conversation.title,
            providerId = exported.conversation.providerId,
            modelName = exported.conversation.modelName,
            systemPrompt = exported.conversation.systemPrompt,
            isPinned = exported.conversation.isPinned,
            tags = exported.conversation.tags,
            createdAt = exported.conversation.createdAt,
            updatedAt = exported.conversation.updatedAt
        )
        val messages = exported.messages.map { msg ->
            Message(
                id = msg.id,
                conversationId = conversation.id,
                role = Message.Role.valueOf(msg.role),
                content = msg.content,
                timestamp = msg.timestamp,
                tokenCount = msg.tokenCount
            )
        }
        return conversation to messages
    }

    /**
     * Export multiple conversations to a single JSON file.
     */
    fun exportMultipleToJson(conversations: List<Pair<Conversation, List<Message>>>): String {
        val exports = conversations.map { (conv, msgs) ->
            ExportedConversation(
                conversation = ConversationData(
                    id = conv.id,
                    title = conv.title,
                    providerId = conv.providerId,
                    modelName = conv.modelName,
                    systemPrompt = conv.systemPrompt,
                    isPinned = conv.isPinned,
                    tags = conv.tags,
                    createdAt = conv.createdAt,
                    updatedAt = conv.updatedAt
                ),
                messages = msgs.map { msg ->
                    MessageData(
                        id = msg.id,
                        role = msg.role.name,
                        content = msg.content,
                        timestamp = msg.timestamp,
                        tokenCount = msg.tokenCount
                    )
                }
            )
        }
        return json.encodeToString(exports)
    }
}
