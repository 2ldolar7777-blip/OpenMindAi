package com.openmind.data.db

import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey
import com.openmind.data.model.Conversation

@Entity(
    tableName = "conversations",
    indices = [
        Index(value = ["updatedAt"], name = "index_conversations_updated_at"),
        Index(value = ["providerId"], name = "index_conversations_provider_id"),
        Index(value = ["isPinned"], name = "index_conversations_pinned")
    ]
)
data class ConversationEntity(
    @PrimaryKey val id: String,
    val title: String?,
    val providerId: String?,
    val modelName: String?,
    val systemPrompt: String?,
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis(),
    val messageCount: Int = 0,
    val isPinned: Boolean = false,
    val tags: String? = null // JSON array string
) {
    fun toDomain(): Conversation = Conversation(
        id = id,
        title = title,
        providerId = providerId,
        modelName = modelName,
        systemPrompt = systemPrompt,
        createdAt = createdAt,
        updatedAt = updatedAt,
        messageCount = messageCount,
        isPinned = isPinned,
        tags = tags?.let {
            try { kotlinx.serialization.json.Json.decodeFromString<List<String>>(it) }
            catch (e: Exception) { emptyList() }
        } ?: emptyList()
    )
}

fun Conversation.toEntity(): ConversationEntity = ConversationEntity(
    id = id,
    title = title,
    providerId = providerId,
    modelName = modelName,
    systemPrompt = systemPrompt,
    createdAt = createdAt,
    updatedAt = updatedAt,
    messageCount = messageCount,
    isPinned = isPinned,
    tags = if (tags.isNotEmpty()) kotlinx.serialization.json.Json.encodeToString(tags) else null
)
