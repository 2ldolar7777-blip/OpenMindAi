package com.openmind.data.model

/**
 * Represents the full response from an AI provider.
 */
data class AIResponse(
    val fullText: String,
    val model: String? = null,
    val providerId: String? = null,
    val usage: Usage? = null
) {
    /**
     * Represents a single part/token of a streaming response.
     * The ViewModel collects these parts to build the full response progressively.
     */
    data class Part(
        val token: String,
        val isFinal: Boolean = false,
        val isThinking: Boolean = false,
        val metadata: Map<String, String> = emptyMap()
    )

    /**
     * Token usage information returned by the provider.
     */
    data class Usage(
        val promptTokens: Int = 0,
        val completionTokens: Int = 0,
        val totalTokens: Int = 0
    )

    companion object {
        fun final() = Part(token = "", isFinal = true)
    }
}
