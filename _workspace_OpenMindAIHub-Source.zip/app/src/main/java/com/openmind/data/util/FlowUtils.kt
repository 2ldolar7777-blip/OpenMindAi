package com.openmind.data.util

import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.onStart

/**
 * Utility extensions for Kotlin Flows used throughout the app.
 */

/**
 * Wrapper to hold UI state from a Flow: Loading, Success, or Error.
 */
sealed interface UiState<out T> {
    data object Loading : UiState<Nothing>
    data class Success<T>(val data: T) : UiState<T>
    data class Error(val message: String, val cause: Throwable? = null) : UiState<Nothing>
}

/**
 * Convert a Flow<T> into a Flow<UiState<T>> with Loading/Success/Error states.
 */
fun <T> Flow<T>.asUiState(): Flow<UiState<T>> =
    this.map<T, UiState<T>> { UiState.Success(it) }
        .onStart { emit(UiState.Loading) }
        .catch { e -> emit(UiState.Error(e.message ?: "Unknown error", e)) }

/**
 * Retry a flow with exponential backoff on error.
 * @param retries Number of retry attempts
 * @param initialDelayMs Initial delay before first retry (doubles each retry)
 * @param maxDelayMs Maximum delay between retries
 */
fun <T> Flow<T>.retryWithBackoff(
    retries: Int = 3,
    initialDelayMs: Long = 1000,
    maxDelayMs: Long = 10000
): Flow<T> {
    var retryCount = 0
    return this.catch { e ->
        if (retryCount < retries) {
            retryCount++
            val delay = minOf(initialDelayMs * (1L shl retryCount), maxDelayMs)
            kotlinx.coroutines.delay(delay)
            throw e // Re-throw to allow upstream retry
        } else {
            throw e
        }
    }
}

/**
 * Map the data inside a UiState.Success, propagating Loading/Error as-is.
 */
fun <T, R> UiState<T>.mapSuccess(transform: (T) -> R): UiState<R> = when (this) {
    is UiState.Loading -> UiState.Loading
    is UiState.Success -> UiState.Success(transform(data))
    is UiState.Error -> UiState.Error(message, cause)
}

/**
 * Get the data from a UiState or null if not successful.
 */
val <T> UiState<T>.dataOrNull: T?
    get() = when (this) {
        is UiState.Success -> data
        else -> null
    }

/**
 * Check if the UiState is currently loading.
 */
val UiState<*>.isLoading: Boolean
    get() = this is UiState.Loading

/**
 * Check if the UiState represents an error.
 */
val UiState<*>.isError: Boolean
    get() = this is UiState.Error

/**
 * Get error message from UiState or null.
 */
val UiState<*>.errorMessage: String?
    get() = (this as? UiState.Error)?.message
