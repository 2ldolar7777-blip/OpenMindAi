package com.openmind.data.backup

import android.app.backup.BackupAgentHelper
import android.app.backup.SharedPreferencesBackupHelper

/**
 * Backup agent for OpenMind AI Hub.
 * Handles selective backup/restore of app data.
 * API keys are excluded from backup for security.
 */
class OpenMindBackupAgent : BackupAgentHelper() {

    companion object {
        private const val PREFS_KEY = "user_prefs"
        private const val PREFS_NAME = "com.openmind.preferences"
    }

    override fun onCreate() {
        // Backup user preferences (theme, chat settings) but NOT encrypted API keys
        addHelper(PREFS_KEY, SharedPreferencesBackupHelper(this, PREFS_NAME))
    }
}
