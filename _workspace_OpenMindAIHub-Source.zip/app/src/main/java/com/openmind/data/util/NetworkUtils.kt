package com.openmind.data.util

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.net.InetSocketAddress
import java.net.Socket

/**
 * Network utility functions for connectivity checks and diagnostics.
 */
object NetworkUtils {

    /**
     * Check if the device can reach a specific host and port.
     * @param host Hostname to check
     * @param port Port to check (default 443 for HTTPS)
     * @param timeoutMs Connection timeout in milliseconds
     * @return true if the host is reachable
     */
    suspend fun isHostReachable(
        host: String,
        port: Int = 443,
        timeoutMs: Int = 5000
    ): Boolean = withContext(Dispatchers.IO) {
        try {
            Socket().use { socket ->
                socket.connect(InetSocketAddress(host, port), timeoutMs)
                true
            }
        } catch (e: Exception) {
            false
        }
    }

    /**
     * Check if an Ollama server is reachable at the given URL.
     * Ollama typically runs on port 11434.
     */
    suspend fun isOllamaReachable(baseUrl: String): Boolean {
        val host = baseUrl.removePrefix("http://").removePrefix("https://")
            .removeSuffix("/").split(":").first()
        val port = baseUrl.removePrefix("http://").removePrefix("https://")
            .removeSuffix("/").split(":").getOrNull(1)?.toIntOrNull() ?: 11434
        return isHostReachable(host, port, timeoutMs = 3000)
    }

    /**
     * Validate and normalize a base URL for API calls.
     * Removes trailing slashes, ensures protocol prefix.
     */
    fun normalizeBaseUrl(url: String): String {
        var normalized = url.trim().trimEnd('/')
        if (!normalized.startsWith("http://") && !normalized.startsWith("https://")) {
            normalized = "https://$normalized"
        }
        return normalized
    }

    /**
     * Extract the host from a URL for display purposes.
     */
    fun extractHost(url: String): String {
        return url.removePrefix("http://").removePrefix("https://")
            .split("/").first().split(":").first()
    }

    /**
     * Build a connection test URL for a provider type.
     */
    fun getConnectionTestUrl(baseUrl: String, providerType: String): String {
        val normalized = normalizeBaseUrl(baseUrl)
        return when (providerType.uppercase()) {
            "OLLAMA" -> "$normalized/api/tags"
            "OPENAI" -> "$normalized/v1/models"
            "ANTHROPIC" -> "$normalized/v1/models"
            "GEMINI" -> "$normalized/v1/models"
            "GROQ" -> "$normalized/v1/models"
            "MISTRAL" -> "$normalized/v1/models"
            else -> "$normalized/v1/models"
        }
    }
}
