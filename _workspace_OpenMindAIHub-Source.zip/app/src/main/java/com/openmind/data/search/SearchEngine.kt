package com.openmind.data.search

import com.openmind.data.model.Conversation
import com.openmind.data.model.Message

/**
 * Search engine for conversations and messages.
 * Supports fuzzy matching, keyword search, and date filtering.
 */
object SearchEngine {

    data class SearchResult(
        val conversation: Conversation,
        val matchingMessages: List<MatchedMessage>,
        val score: Double
    )

    data class MatchedMessage(
        val message: Message,
        val matchedRange: IntRange,
        val contextBefore: String,
        val contextAfter: String
    )

    /**
     * Search through conversations and messages.
     * @param query The search query string
     * @param conversations List of conversations to search through
     * @param messagesByConversation Map of conversation ID to messages
     * @param maxResults Maximum number of results to return
     * @return List of search results sorted by relevance score
     */
    fun search(
        query: String,
        conversations: List<Conversation>,
        messagesByConversation: Map<String, List<Message>>,
        maxResults: Int = 50
    ): List<SearchResult> {
        if (query.isBlank()) return emptyList()

        val normalizedQuery = query.lowercase().trim()
        val keywords = normalizedQuery.split("\\s+".toRegex()).filter { it.length >= 2 }

        val results = mutableListOf<SearchResult>()

        for (conversation in conversations) {
            val matchingMessages = mutableListOf<MatchedMessage>()
            var totalScore = 0.0

            // Search in conversation title
            val titleScore = calculateRelevanceScore(normalizedQuery, conversation.title.lowercase())
            totalScore += titleScore * 2.0 // Title matches are weighted more

            // Search in messages
            val messages = messagesByConversation[conversation.id] ?: emptyList()
            for (message in messages) {
                val contentLower = message.content.lowercase()
                val matchRange = findBestMatch(normalizedQuery, contentLower)

                if (matchRange != null) {
                    val messageScore = calculateRelevanceScore(normalizedQuery, contentLower)
                    totalScore += messageScore

                    val contextSize = 50
                    val contextStart = maxOf(0, matchRange.first - contextSize)
                    val contextEnd = minOf(message.content.length, matchRange.last + contextSize)

                    matchingMessages.add(
                        MatchedMessage(
                            message = message,
                            matchedRange = matchRange,
                            contextBefore = message.content.substring(contextStart, matchRange.first),
                            contextAfter = message.content.substring(
                                matchRange.last + 1,
                                minOf(message.content.length, matchRange.last + contextSize)
                            )
                        )
                    )
                }
            }

            // Also check keyword matches
            for (keyword in keywords) {
                if (conversation.title.lowercase().contains(keyword)) {
                    totalScore += 0.5
                }
            }

            if (matchingMessages.isNotEmpty() || titleScore > 0) {
                results.add(
                    SearchResult(
                        conversation = conversation,
                        matchingMessages = matchingMessages,
                        score = totalScore
                    )
                )
            }
        }

        return results
            .sortedByDescending { it.score }
            .take(maxResults)
    }

    /**
     * Calculate a relevance score for a query against a text.
     * Uses simple TF-based scoring with proximity bonus.
     */
    private fun calculateRelevanceScore(query: String, text: String): Double {
        var score = 0.0
        val keywords = query.split("\\s+".toRegex()).filter { it.length >= 2 }

        for (keyword in keywords) {
            var idx = text.indexOf(keyword)
            while (idx >= 0) {
                score += 1.0
                // Exact phrase match bonus
                if (text.contains(query)) {
                    score += 2.0
                }
                // Position bonus - matches near the start rank higher
                if (idx < 100) {
                    score += 0.5
                }
                idx = text.indexOf(keyword, idx + 1)
            }
        }

        return score
    }

    /**
     * Find the best matching range in the text for the query.
     */
    private fun findBestMatch(query: String, text: String): IntRange? {
        // Try exact match first
        val exactIdx = text.indexOf(query)
        if (exactIdx >= 0) {
            return exactIdx until (exactIdx + query.length)
        }

        // Try keyword matches
        val keywords = query.split("\\s+".toRegex()).filter { it.length >= 2 }
        for (keyword in keywords) {
            val idx = text.indexOf(keyword)
            if (idx >= 0) {
                return idx until (idx + keyword.length)
            }
        }

        return null
    }

    /**
     * Highlight matching text in a string for display.
     * Returns a list of text segments with their highlight status.
     */
    fun highlightMatches(text: String, query: String): List<TextSegment> {
        if (query.isBlank()) return listOf(TextSegment(text, false))

        val segments = mutableListOf<TextSegment>()
        val lowerText = text.lowercase()
        val lowerQuery = query.lowercase().trim()

        var lastEnd = 0
        var idx = lowerText.indexOf(lowerQuery)

        while (idx >= 0) {
            if (idx > lastEnd) {
                segments.add(TextSegment(text.substring(lastEnd, idx), false))
            }
            segments.add(TextSegment(text.substring(idx, idx + lowerQuery.length), true))
            lastEnd = idx + lowerQuery.length
            idx = lowerText.indexOf(lowerQuery, lastEnd)
        }

        if (lastEnd < text.length) {
            segments.add(TextSegment(text.substring(lastEnd), false))
        }

        return segments
    }

    data class TextSegment(val text: String, val isHighlighted: Boolean)
}
