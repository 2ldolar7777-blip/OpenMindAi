package com.openmind.data.db

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Dao
interface ProviderConfigDao {

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(config: ProviderConfigEntity): Long

    @Update
    suspend fun update(config: ProviderConfigEntity)

    @Delete
    suspend fun delete(config: ProviderConfigEntity)

    @Query("DELETE FROM provider_configs WHERE id = :id")
    suspend fun deleteById(id: String)

    @Query("DELETE FROM provider_configs")
    suspend fun deleteAll()

    @Query("SELECT * FROM provider_configs WHERE id = :id")
    suspend fun getById(id: String): ProviderConfigEntity?

    @Query("SELECT * FROM provider_configs WHERE id = :id")
    fun getByIdFlow(id: String): Flow<ProviderConfigEntity?>

    @Query("SELECT * FROM provider_configs ORDER BY `order` ASC, name ASC")
    fun getAllFlow(): Flow<List<ProviderConfigEntity>>

    @Query("SELECT * FROM provider_configs ORDER BY `order` ASC, name ASC")
    suspend fun getAll(): List<ProviderConfigEntity>

    @Query("SELECT * FROM provider_configs WHERE isEnabled = 1 ORDER BY `order` ASC, name ASC")
    fun getEnabledFlow(): Flow<List<ProviderConfigEntity>>

    @Query("SELECT * FROM provider_configs WHERE isEnabled = 1 ORDER BY `order` ASC, name ASC")
    suspend fun getEnabled(): List<ProviderConfigEntity>

    @Query("SELECT * FROM provider_configs WHERE type = :type ORDER BY name ASC")
    fun getByTypeFlow(type: String): Flow<List<ProviderConfigEntity>>

    @Query("SELECT * FROM provider_configs WHERE isDefault = 1 LIMIT 1")
    suspend fun getDefault(): ProviderConfigEntity?

    @Query("UPDATE provider_configs SET isEnabled = :enabled WHERE id = :id")
    suspend fun setEnabled(id: String, enabled: Boolean)

    @Query("UPDATE provider_configs SET isDefault = :isDefault WHERE id = :id")
    suspend fun setDefault(id: String, isDefault: Boolean)

    @Query("UPDATE provider_configs SET apiKey = :apiKey WHERE id = :id")
    suspend fun updateApiKey(id: String, apiKey: String?)

    @Query("UPDATE provider_configs SET `order` = :order WHERE id = :id")
    suspend fun updateOrder(id: String, order: Int)

    @Query("SELECT COUNT(*) FROM provider_configs")
    suspend fun count(): Int
}
