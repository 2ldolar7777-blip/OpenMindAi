package com.openmind.data.provider

import android.util.Log
import com.openmind.data.db.ProviderConfigDao
import com.openmind.data.model.ModelInfo
import com.openmind.data.model.ProviderConfig
import kotlinx.coroutines.*
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Manages AI provider instances dynamically.
 * Loads ProviderConfig rows from the database and instantiates
 * the corresponding AIProvider implementation at runtime.
 *
 * New providers can be added simply by inserting a ProviderConfig row
 * (via UI or API) — no code change or rebuild required for generic providers.
 */
@Singleton
class ProviderManager @Inject constructor(
    private val providerConfigDao: ProviderConfigDao
) {
    companion object {
        private const val TAG = "ProviderManager"
    }

    private val mutex = Mutex()
    private val instances = mutableMapOf<String, AIProvider>()
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    // Cache for model lists
    private val modelListCache = mutableMapOf<String, List<ModelInfo>>()

    /**
     * Get a provider instance by its configuration ID.
     * Creates the instance on first access and caches it.
     */
    suspend fun getProvider(id: String): AIProvider? {
        mutex.withLock {
            return instances[id] ?: createProvider(id)
        }
    }

    /**
     * Get the default provider (the one marked as default in DB).
     */
    suspend fun getDefaultProvider(): AIProvider? {
        val defaultConfig = providerConfigDao.getDefault() ?: return null
        return getProvider(defaultConfig.id)
    }

    /**
     * Get all available provider configurations.
     */
    suspend fun listAvailable(): List<ProviderConfig> =
        providerConfigDao.getEnabled().map { it.toDomain() }

    /**
     * Get all provider configurations as a Flow for reactive updates.
     */
    fun listAvailableFlow() = providerConfigDao.getEnabledFlow()

    /**
     * Reload a provider (e.g., after config change).
     * Closes the old instance and creates a new one.
     */
    suspend fun reloadProvider(id: String) {
        mutex.withLock {
            instances[id]?.close()
            instances.remove(id)
            modelListCache.remove(id)
            createProvider(id)
        }
    }

    /**
     * Remove a provider instance from cache.
     */
    suspend fun removeProvider(id: String) {
        mutex.withLock {
            instances[id]?.close()
            instances.remove(id)
            modelListCache.remove(id)
        }
    }

    /**
     * Get models for a specific provider.
     * Results are cached for performance.
     */
    suspend fun getModelsForProvider(providerId: String): List<ModelInfo> {
        modelListCache[providerId]?.let { return it }

        val provider = getProvider(providerId) ?: return emptyList()
        return try {
            val models = provider.getModelList()
            modelListCache[providerId] = models
            models
        } catch (e: Exception) {
            Log.e(TAG, "Failed to get models for provider $providerId", e)
            emptyList()
        }
    }

    /**
     * Invalidate model list cache for a provider.
     */
    fun invalidateModelCache(providerId: String) {
        modelListCache.remove(providerId)
    }

    /**
     * Test connection to a provider.
     */
    suspend fun testProviderConnection(id: String): Boolean {
        val provider = getProvider(id) ?: return false
        return try {
            provider.testConnection()
        } catch (e: Exception) {
            Log.e(TAG, "Connection test failed for provider $id", e)
            false
        }
    }

    /**
     * Create a provider instance based on its configuration type.
     */
    private suspend fun createProvider(id: String): AIProvider? {
        val configEntity = providerConfigDao.getById(id) ?: return null
        val config = configEntity.toDomain()

        if (!config.isEnabled) {
            Log.w(TAG, "Provider $id is disabled, skipping creation")
            return null
        }

        val provider: AIProvider = when (config.type) {
            ProviderConfig.ProviderType.OLLAMA -> OllamaProvider(config)
            ProviderConfig.ProviderType.OPENAI_MOCK -> OpenAIMockProvider(config)
            ProviderConfig.ProviderType.OPENAI -> GenericHttpProvider(config)
            ProviderConfig.ProviderType.ANTHROPIC -> GenericHttpProvider(config)
            ProviderConfig.ProviderType.GEMINI -> GenericHttpProvider(config)
            ProviderConfig.ProviderType.GROQ -> GenericHttpProvider(config)
            ProviderConfig.ProviderType.MISTRAL -> GenericHttpProvider(config)
            ProviderConfig.ProviderType.GENERIC -> GenericHttpProvider(config)
        }

        instances[id] = provider
        Log.i(TAG, "Created provider instance: ${config.name} (type=${config.type.value})")
        return provider
    }

    /**
     * Close all provider instances and release resources.
     */
    fun closeAll() {
        scope.cancel()
        instances.values.forEach { it.close() }
        instances.clear()
        modelListCache.clear()
    }
}
