package com.openmind.data.db

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey
import com.openmind.data.model.ProviderConfig

@Entity(
    tableName = "provider_configs",
    indices = [
        Index(value = ["type"], name = "index_provider_config_type"),
        Index(value = ["isEnabled"], name = "index_provider_config_enabled")
    ]
)
data class ProviderConfigEntity(
    @PrimaryKey val id: String,
    val name: String,
    val type: String,
    val baseUrl: String,
    val apiKey: String?,
    val meta: String?,
    val isEnabled: Boolean = true,
    val isDefault: Boolean = false,
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis(),
    val order: Int = 0
) {
    fun toDomain(): ProviderConfig = ProviderConfig(
        id = id,
        name = name,
        type = ProviderConfig.ProviderType.fromValue(type),
        baseUrl = baseUrl,
        apiKey = apiKey,
        meta = meta,
        isEnabled = isEnabled,
        isDefault = isDefault,
        createdAt = createdAt,
        updatedAt = updatedAt,
        order = order
    )
}

fun ProviderConfig.toEntity(): ProviderConfigEntity = ProviderConfigEntity(
    id = id,
    name = name,
    type = type.value,
    baseUrl = baseUrl,
    apiKey = apiKey,
    meta = meta,
    isEnabled = isEnabled,
    isDefault = isDefault,
    createdAt = createdAt,
    updatedAt = updatedAt,
    order = order
)
