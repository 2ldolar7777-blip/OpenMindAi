package com.openmind.data.provider

import com.openmind.data.model.*
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import kotlin.random.Random

/**
 * Mock provider for development and testing.
 * Simulates streaming AI responses without requiring any API connection.
 * Produces realistic-looking responses with typing delays.
 */
class OpenAIMockProvider(private val cfg: ProviderConfig) : AIProvider {

    companion object {
        private val MOCK_RESPONSES = listOf(
            """I'd be happy to help you with that! Let me break this down step by step.

First, let's consider the key aspects of your question. The important thing to understand is that this topic has multiple dimensions that we should explore.

**Key Points:**
1. The fundamental concept here relates to how we process and analyze information
2. There are several approaches we can take to solve this
3. Each approach has its own trade-offs

Here's a practical example:
```kotlin
fun processInput(data: String): Result {
    return when {
        data.isEmpty() -> Result.Error("Input cannot be empty")
        data.length > 1000 -> Result.Warning("Large input may take longer")
        else -> Result.Success(analyze(data))
    }
}
```

Let me know if you'd like me to elaborate on any of these points!""",

            """That's a great question! Let me think through this carefully.

The answer depends on several factors:

**Factor 1: Context**
Understanding the context is crucial. Without proper context, any solution might miss important nuances.

**Factor 2: Trade-offs**
Every decision involves trade-offs. The key is to identify which trade-offs are acceptable for your specific use case.

**Factor 3: Best Practices**
Following established best practices can save time and prevent common pitfalls:
- Always validate inputs at the boundary
- Use dependency injection for testability
- Keep your functions pure when possible
- Write tests before fixing bugs

Here's a summary table:

| Approach | Pros | Cons |
|----------|------|------|
| Method A | Fast, simple | Limited flexibility |
| Method B | Flexible | More complex |
| Method C | Balanced | Moderate learning curve |

Would you like to dive deeper into any of these approaches?""",

            """Absolutely! Here's what I can tell you about this topic.

## Overview

This is a fascinating area that combines several disciplines. The core idea revolves around creating systems that can adapt and respond intelligently to various inputs.

### Architecture

A well-designed system typically follows these layers:

1. **Presentation Layer** — Handles user interface and interaction
2. **Business Logic Layer** — Contains core rules and processing
3. **Data Access Layer** — Manages persistence and retrieval

```python
class SmartAgent:
    def __init__(self, config):
        self.model = load_model(config.model_path)
        self.memory = VectorStore(config.embedding_dim)
        
    async def process(self, input_text):
        context = await self.memory.search(input_text)
        response = await self.model.generate(input_text, context)
        await self.memory.store(input_text, response)
        return response
```

### Key Takeaways

- Design for extensibility from the start
- Use abstraction layers to isolate changes
- Test thoroughly, especially edge cases
- Document your decisions and rationale

Is there a specific aspect you'd like me to expand on?""",

            """Here's my analysis of your question:

## Short Answer
The approach you're describing is viable, but there are some important considerations to keep in mind.

## Detailed Analysis

### Pros
- ✅ Clean separation of concerns
- ✅ Easy to test and maintain
- ✅ Scales well with complexity
- ✅ Follows SOLID principles

### Cons
- ❌ Initial setup is more involved
- ❌ More boilerplate code
- ❌ Learning curve for new team members

### Recommendation

I'd recommend starting with a simpler approach and refactoring toward the more complex one as needed. Here's why:

> "Make it work, make it right, make it fast." — Kent Beck

The incremental approach allows you to:
1. Deliver value sooner
2. Learn from real usage patterns
3. Avoid over-engineering

What are your thoughts on this approach?""",

            """Let me help you understand this concept better!

## The Basics

Think of it like building blocks. Each piece serves a specific purpose:

```
┌─────────────────┐
│   User Input     │
└────────┬────────┘
         │
    ┌────▼────┐
    │ Process  │
    └────┬────┘
         │
    ┌────▼────┐
    │ Validate │
    └────┬────┘
         │
    ┌────▼────┐
    │  Output  │
    └─────────┘
```

## Implementation

Here's a clean implementation:

```rust
struct Pipeline {
    steps: Vec<Box<dyn Step>>,
}

impl Pipeline {
    fn execute(&self, input: Data) -> Result<Data> {
        self.steps.iter().try_fold(input, |data, step| {
            step.process(data)
        })
    }
}
```

## Performance Tips

- Cache frequently accessed data
- Use lazy evaluation where possible
- Profile before optimizing
- Consider async for I/O-bound operations

Feel free to ask follow-up questions! 🚀"""
        )
    }

    override val id: String = cfg.id
    override val displayName: String = cfg.name
    override val supportsStreaming: Boolean = true
    override val isLocal: Boolean = true

    override suspend fun getModelList(): List<ModelInfo> = listOf(
        ModelInfo("gpt-mock-4", "GPT Mock 4", "Most capable mock model", contextLength = 128000),
        ModelInfo("gpt-mock-3.5", "GPT Mock 3.5", "Fast and affordable mock model", contextLength = 16385),
        ModelInfo("mock-mini", "Mock Mini", "Lightweight mock model", contextLength = 8192)
    )

    override fun streamCompletion(
        prompt: String,
        context: List<Message>,
        model: String?,
        temperature: Float?,
        maxTokens: Int?,
        systemPrompt: String?
    ): Flow<AIResponse.Part> = flow {
        // Select a random mock response
        val responseIndex = Random.nextInt(MOCK_RESPONSES.size)
        val answer = MOCK_RESPONSES[responseIndex]

        // Simulate token-by-token streaming
        // Split into smaller chunks for more realistic streaming
        val chars = answer.toCharArray()
        val chunkSize = Random.nextInt(2, 5)
        var i = 0

        while (i < chars.size) {
            val end = minOf(i + chunkSize, chars.size)
            val token = String(chars, i, end - i)
            emit(AIResponse.Part(token = token, isFinal = false))
            i = end
            // Variable delay for realistic feel
            delay(Random.nextLong(15, 45))
        }

        emit(AIResponse.Part(token = "", isFinal = true))
    }

    override suspend fun testConnection(): Boolean = true

    override fun close() {
        // No resources to clean up
    }

    override fun cancel() {
        // Nothing to cancel for mock
    }
}
