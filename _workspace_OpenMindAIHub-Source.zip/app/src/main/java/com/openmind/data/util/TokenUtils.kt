package com.openmind.data.util

/**
 * Utility for estimating token counts for text.
 *
 * Uses a simple heuristic: ~4 characters per token for English text,
 * with adjustments for code and special content.
 * For production, use tiktoken or the provider's tokenizer API.
 */
object TokenUtils {

    private const val CHARS_PER_TOKEN = 4.0
    private const val CODE_CHARS_PER_TOKEN = 3.5  // Code is denser
    private const val WHITESPACE_OVERHEAD = 1.1    // Whitespace adds tokens

    /**
     * Estimate the token count for a text string.
     * @param text The text to estimate tokens for
     * @param isCode Whether the text is code (uses different heuristic)
     * @return Estimated token count
     */
    fun estimateTokens(text: String, isCode: Boolean = false): Int {
        if (text.isBlank()) return 0

        val charsPerToken = if (isCode) CODE_CHARS_PER_TOKEN else CHARS_PER_TOKEN
        val baseTokens = text.length / charsPerToken

        // Adjust for whitespace patterns
        val whitespaceCount = text.count { it.isWhitespace() }
        val whitespaceAdjustment = whitespaceCount * (WHITESPACE_OVERHEAD - 1.0) / charsPerToken

        // Adjust for special characters
        val specialCount = text.count { !it.isLetterOrDigit() && !it.isWhitespace() }
        val specialAdjustment = specialCount * 0.2 / charsPerToken

        return (baseTokens + whitespaceAdjustment + specialAdjustment).toInt().coerceAtLeast(1)
    }

    /**
     * Estimate tokens for a list of messages (conversation context).
     */
    fun estimateConversationTokens(
        messages: List<Pair<String, String>>, // role to content
        systemPrompt: String? = null
    ): Int {
        var total = 0

        // System prompt overhead
        if (systemPrompt != null) {
            total += estimateTokens(systemPrompt) + 4 // role overhead
        }

        // Message tokens + role/formatting overhead
        messages.forEach { (role, content) ->
            total += estimateTokens(content) + 4 // role + separator overhead
        }

        // Response priming overhead
        total += 3 // assistant prefix

        return total
    }

    /**
     * Truncate text to fit within a maximum token budget.
     * @param text The text to truncate
     * @param maxTokens Maximum token budget
     * @return Truncated text that fits within the budget
     */
    fun truncateToTokenBudget(text: String, maxTokens: Int): String {
        val estimatedChars = (maxTokens * CHARS_PER_TOKEN).toInt()
        if (text.length <= estimatedChars) return text
        return text.take(estimatedChars) + "..."
    }

    /**
     * Format token count for display.
     */
    fun formatTokenCount(count: Int): String {
        return when {
            count < 1000 -> "$count"
            count < 1_000_000 -> "${count / 1000}.${(count % 1000) / 100}k"
            else -> "${count / 1_000_000}M"
        }
    }

    /**
     * Calculate approximate cost for a model call.
     * @param inputTokens Number of input tokens
     * @param outputTokens Number of output tokens
     * @param pricePerMillionInput Price per million input tokens in USD
     * @param pricePerMillionOutput Price per million output tokens in USD
     * @return Approximate cost string in USD
     */
    fun estimateCost(
        inputTokens: Int,
        outputTokens: Int,
        pricePerMillionInput: Double,
        pricePerMillionOutput: Double
    ): String {
        val cost = (inputTokens * pricePerMillionInput + outputTokens * pricePerMillionOutput) / 1_000_000
        return when {
            cost < 0.001 -> "<$0.001"
            cost < 0.01 -> "$${String.format("%.4f", cost)}"
            cost < 1.0 -> "$${String.format("%.3f", cost)}"
            else -> "$${String.format("%.2f", cost)}"
        }
    }
}
