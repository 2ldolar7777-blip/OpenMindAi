package com.openmind.data.util

/**
 * Markdown parsing utilities for chat message rendering.
 * Provides structured parsing of markdown content for Compose rendering.
 */

/**
 * Represents a parsed markdown block/element.
 */
sealed class MarkdownElement {
    data class Header(val text: String, val level: Int) : MarkdownElement()
    data class Paragraph(val text: String) : MarkdownElement()
    data class CodeBlock(val code: String, val language: String?) : MarkdownElement()
    data class InlineCode(val code: String) : MarkdownElement()
    data class ListItem(val text: String, val indent: Int, val ordered: Boolean, val index: Int) : MarkdownElement()
    data class BlockQuote(val text: String) : MarkdownElement()
    data object HorizontalRule : MarkdownElement()
    data class Bold(val text: String) : MarkdownElement()
    data class Italic(val text: String) : MarkdownElement()
    data class Link(val text: String, val url: String) : MarkdownElement()
    data class Image(val alt: String, val url: String) : MarkdownElement()
    data class Strikethrough(val text: String) : MarkdownElement()
}

/**
 * Parse markdown text into a list of structured elements.
 * This is used alongside the inline Compose rendering for more complex parsing.
 */
object MarkdownUtils {

    /**
     * Parse markdown content into block-level elements.
     * Handles: headers, code blocks, lists, blockquotes, horizontal rules, paragraphs.
     */
    fun parseBlocks(markdown: String): List<MarkdownElement> {
        val elements = mutableListOf<MarkdownElement>()
        val lines = markdown.lines()
        var i = 0

        while (i < lines.size) {
            val line = lines[i]

            // Skip empty lines
            if (line.isBlank()) {
                i++
                continue
            }

            // Horizontal rule
            if (isHorizontalRule(line)) {
                elements.add(MarkdownElement.HorizontalRule)
                i++
                continue
            }

            // Header
            val headerMatch = HEADER_REGEX.matchEntire(line)
            if (headerMatch != null) {
                val level = headerMatch.groupValues[1].length
                val text = headerMatch.groupValues[2].trim()
                elements.add(MarkdownElement.Header(text, level))
                i++
                continue
            }

            // Code block (fenced)
            if (line.trimStart().startsWith("```")) {
                val lang = line.trimStart().removePrefix("```").trim()
                val codeLines = mutableListOf<String>()
                i++
                while (i < lines.size && !lines[i].trimStart().startsWith("```")) {
                    codeLines.add(lines[i])
                    i++
                }
                i++ // skip closing ```
                elements.add(MarkdownElement.CodeBlock(
                    code = codeLines.joinToString("\n"),
                    language = lang.ifBlank { null }
                ))
                continue
            }

            // Blockquote
            if (line.trimStart().startsWith(">")) {
                val quoteLines = mutableListOf<String>()
                while (i < lines.size && lines[i].trimStart().startsWith(">")) {
                    quoteLines.add(lines[i].trimStart().removePrefix(">").trim())
                    i++
                }
                elements.add(MarkdownElement.BlockQuote(quoteLines.joinToString("\n")))
                continue
            }

            // List item
            if (isListItem(line)) {
                val isOrdered = ORDERED_LIST_REGEX.matches(line.trimStart())
                var itemIndex = 1
                while (i < lines.size && isListItem(lines[i])) {
                    val indent = lines[i].count { it == ' ' || it == '\t' }
                    val text = lines[i].trimStart()
                        .replaceFirst(UNORDERED_LIST_REGEX, "")
                        .replaceFirst(ORDERED_LIST_REGEX, "")
                        .trim()
                    elements.add(MarkdownElement.ListItem(text, indent, isOrdered, itemIndex))
                    if (isOrdered) itemIndex++
                    i++
                }
                continue
            }

            // Paragraph (collect consecutive non-empty lines)
            val paraLines = mutableListOf<String>()
            while (i < lines.size && lines[i].isNotBlank() &&
                   !isHorizontalRule(lines[i]) &&
                   !HEADER_REGEX.matches(lines[i]) &&
                   !lines[i].trimStart().startsWith("```") &&
                   !lines[i].trimStart().startsWith(">") &&
                   !isListItem(lines[i])) {
                paraLines.add(lines[i])
                i++
            }
            if (paraLines.isNotEmpty()) {
                elements.add(MarkdownElement.Paragraph(paraLines.joinToString(" ")))
            }
        }

        return elements
    }

    /**
     * Parse inline markdown elements within a text string.
     * Returns a list of segments with their formatting.
     */
    fun parseInline(text: String): List<InlineSegment> {
        val segments = mutableListOf<InlineSegment>()
        var remaining = text

        while (remaining.isNotEmpty()) {
            // Try to match inline code first (highest priority)
            val inlineCodeMatch = INLINE_CODE_REGEX.find(remaining)
            if (inlineCodeMatch != null && inlineCodeMatch.range.first == 0) {
                segments.add(InlineSegment.Code(inlineCodeMatch.groupValues[1]))
                remaining = remaining.removeRange(inlineCodeMatch.range)
                continue
            }

            // Bold
            val boldMatch = BOLD_REGEX.find(remaining)
            if (boldMatch != null && boldMatch.range.first == 0) {
                segments.add(InlineSegment.Bold(boldMatch.groupValues[1]))
                remaining = remaining.removeRange(boldMatch.range)
                continue
            }

            // Italic
            val italicMatch = ITALIC_REGEX.find(remaining)
            if (italicMatch != null && italicMatch.range.first == 0) {
                segments.add(InlineSegment.Italic(italicMatch.groupValues[1]))
                remaining = remaining.removeRange(italicMatch.range)
                continue
            }

            // Link
            val linkMatch = LINK_REGEX.find(remaining)
            if (linkMatch != null && linkMatch.range.first == 0) {
                segments.add(InlineSegment.Link(linkMatch.groupValues[1], linkMatch.groupValues[2]))
                remaining = remaining.removeRange(linkMatch.range)
                continue
            }

            // Strikethrough
            val strikeMatch = STRIKETHROUGH_REGEX.find(remaining)
            if (strikeMatch != null && strikeMatch.range.first == 0) {
                segments.add(InlineSegment.Strikethrough(strikeMatch.groupValues[1]))
                remaining = remaining.removeRange(strikeMatch.range)
                continue
            }

            // Find next special character position
            val nextSpecial = findNextSpecialChar(remaining)
            if (nextSpecial > 0) {
                segments.add(InlineSegment.Plain(remaining.take(nextSpecial)))
                remaining = remaining.drop(nextSpecial)
            } else if (nextSpecial == 0) {
                // Skip the special character if no pattern matched
                segments.add(InlineSegment.Plain(remaining.take(1)))
                remaining = remaining.drop(1)
            } else {
                // No more special characters
                segments.add(InlineSegment.Plain(remaining))
                break
            }
        }

        return segments
    }

    private fun isHorizontalRule(line: String): Boolean {
        val trimmed = line.trim()
        return HORIZONTAL_RULE_REGEX.matches(trimmed)
    }

    private fun isListItem(line: String): Boolean {
        val trimmed = line.trimStart()
        return UNORDERED_LIST_REGEX.matches(trimmed) || ORDERED_LIST_REGEX.matches(trimmed)
    }

    private fun findNextSpecialChar(text: String): Int {
        val specials = listOf("`", "**", "*", "__", "_", "~", "[")
        val positions = specials.mapNotNull { special ->
            val idx = text.indexOf(special)
            if (idx > 0) idx else null
        }
        return positions.minOrNull() ?: -1
    }

    // Regex patterns
    private val HEADER_REGEX = Regex("^(#{1,6})\\s+(.+)$")
    private val HORIZONTAL_RULE_REGEX = Regex("^(\\*{3,}|-{3,}|_{3,})$")
    private val UNORDERED_LIST_REGEX = Regex("^[*+-]\\s")
    private val ORDERED_LIST_REGEX = Regex("^\\d+\\.\\s")
    private val INLINE_CODE_REGEX = Regex("`([^`]+)`")
    private val BOLD_REGEX = Regex("\\*\\*(.+?)\\*\\*")
    private val ITALIC_REGEX = Regex("\\*(.+?)\\*")
    private val LINK_REGEX = Regex("\\[(.+?)]\\((.+?)\\)")
    private val STRIKETHROUGH_REGEX = Regex("~~(.+?)~~")
}

/**
 * Inline segment types for rich text rendering.
 */
sealed class InlineSegment {
    data class Plain(val text: String) : InlineSegment()
    data class Bold(val text: String) : InlineSegment()
    data class Italic(val text: String) : InlineSegment()
    data class Code(val code: String) : InlineSegment()
    data class Link(val text: String, val url: String) : InlineSegment()
    data class Strikethrough(val text: String) : InlineSegment()
}
