package com.openmind.data.repository

import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.*
import com.openmind.data.model.UserPreferences
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.map
import java.io.IOException
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Repository for managing user preferences stored in DataStore.
 */
@Singleton
class PreferencesRepository @Inject constructor(
    private val dataStore: DataStore<Preferences>
) {
    companion object {
        // Preference keys
        val KEY_THEME_MODE = intPreferencesKey("theme_mode")
        val KEY_DYNAMIC_COLOR = booleanPreferencesKey("dynamic_color")
        val KEY_DEFAULT_PROVIDER_ID = stringPreferencesKey("default_provider_id")
        val KEY_DEFAULT_MODEL = stringPreferencesKey("default_model")
        val KEY_SEND_WITH_ENTER = booleanPreferencesKey("send_with_enter")
        val KEY_STREAM_RESPONSES = booleanPreferencesKey("stream_responses")
        val KEY_SHOW_TOKEN_COUNT = booleanPreferencesKey("show_token_count")
        val KEY_FONT_SIZE = intPreferencesKey("font_size")
        val KEY_LANGUAGE = stringPreferencesKey("language")
        val KEY_BACKUP_ENABLED = booleanPreferencesKey("backup_enabled")
        val KEY_AUTO_TITLE = booleanPreferencesKey("auto_title")
        val KEY_MAX_CONTEXT_MESSAGES = intPreferencesKey("max_context_messages")
        val KEY_TEMPERATURE = floatPreferencesKey("temperature")
        val KEY_MAX_TOKENS = intPreferencesKey("max_tokens")
        val KEY_TOP_P = floatPreferencesKey("top_p")
    }

    val preferences: Flow<UserPreferences> = dataStore.data
        .catch { exception ->
            if (exception is IOException) {
                emit(emptyPreferences())
            } else {
                throw exception
            }
        }
        .map { prefs ->
            mapToPreferences(prefs)
        }

    private fun mapToPreferences(prefs: Preferences): UserPreferences = UserPreferences(
        themeMode = UserPreferences.ThemeMode.entries.getOrElse(prefs[KEY_THEME_MODE] ?: 0) { UserPreferences.ThemeMode.SYSTEM },
        dynamicColor = prefs[KEY_DYNAMIC_COLOR] ?: true,
        defaultProviderId = prefs[KEY_DEFAULT_PROVIDER_ID],
        defaultModel = prefs[KEY_DEFAULT_MODEL],
        sendWithEnter = prefs[KEY_SEND_WITH_ENTER] ?: true,
        streamResponses = prefs[KEY_STREAM_RESPONSES] ?: true,
        showTokenCount = prefs[KEY_SHOW_TOKEN_COUNT] ?: false,
        fontSize = UserPreferences.FontSize.entries.getOrElse(prefs[KEY_FONT_SIZE] ?: 1) { UserPreferences.FontSize.MEDIUM },
        language = prefs[KEY_LANGUAGE] ?: "en",
        backupEnabled = prefs[KEY_BACKUP_ENABLED] ?: false,
        autoTitle = prefs[KEY_AUTO_TITLE] ?: true,
        maxContextMessages = prefs[KEY_MAX_CONTEXT_MESSAGES] ?: 20,
        temperature = prefs[KEY_TEMPERATURE] ?: 0.7f,
        maxTokens = prefs[KEY_MAX_TOKENS] ?: 2048,
        topP = prefs[KEY_TOP_P] ?: 1.0f
    )

    suspend fun updateThemeMode(mode: UserPreferences.ThemeMode) {
        dataStore.edit { it[KEY_THEME_MODE] = mode.ordinal }
    }

    suspend fun updateDynamicColor(enabled: Boolean) {
        dataStore.edit { it[KEY_DYNAMIC_COLOR] = enabled }
    }

    suspend fun updateDefaultProvider(providerId: String?) {
        dataStore.edit { it[KEY_DEFAULT_PROVIDER_ID] = providerId ?: "" }
    }

    suspend fun updateDefaultModel(model: String?) {
        dataStore.edit { it[KEY_DEFAULT_MODEL] = model ?: "" }
    }

    suspend fun updateSendWithEnter(enabled: Boolean) {
        dataStore.edit { it[KEY_SEND_WITH_ENTER] = enabled }
    }

    suspend fun updateStreamResponses(enabled: Boolean) {
        dataStore.edit { it[KEY_STREAM_RESPONSES] = enabled }
    }

    suspend fun updateShowTokenCount(enabled: Boolean) {
        dataStore.edit { it[KEY_SHOW_TOKEN_COUNT] = enabled }
    }

    suspend fun updateFontSize(size: UserPreferences.FontSize) {
        dataStore.edit { it[KEY_FONT_SIZE] = size.ordinal }
    }

    suspend fun updateLanguage(language: String) {
        dataStore.edit { it[KEY_LANGUAGE] = language }
    }

    suspend fun updateAutoTitle(enabled: Boolean) {
        dataStore.edit { it[KEY_AUTO_TITLE] = enabled }
    }

    suspend fun updateMaxContextMessages(count: Int) {
        dataStore.edit { it[KEY_MAX_CONTEXT_MESSAGES] = count }
    }

    suspend fun updateTemperature(temperature: Float) {
        dataStore.edit { it[KEY_TEMPERATURE] = temperature }
    }

    suspend fun updateMaxTokens(tokens: Int) {
        dataStore.edit { it[KEY_MAX_TOKENS] = tokens }
    }

    suspend fun updateTopP(topP: Float) {
        dataStore.edit { it[KEY_TOP_P] = topP }
    }

    suspend fun updatePreferences(transform: (UserPreferences) -> UserPreferences) {
        dataStore.edit { prefs ->
            val current = mapToPreferences(prefs)
            val updated = transform(current)
            // Apply all changes
            prefs[KEY_THEME_MODE] = updated.themeMode.ordinal
            prefs[KEY_DYNAMIC_COLOR] = updated.dynamicColor
            prefs[KEY_SEND_WITH_ENTER] = updated.sendWithEnter
            prefs[KEY_STREAM_RESPONSES] = updated.streamResponses
            prefs[KEY_SHOW_TOKEN_COUNT] = updated.showTokenCount
            prefs[KEY_FONT_SIZE] = updated.fontSize.ordinal
            prefs[KEY_LANGUAGE] = updated.language
            prefs[KEY_AUTO_TITLE] = updated.autoTitle
            prefs[KEY_MAX_CONTEXT_MESSAGES] = updated.maxContextMessages
            prefs[KEY_TEMPERATURE] = updated.temperature
            prefs[KEY_MAX_TOKENS] = updated.maxTokens
            prefs[KEY_TOP_P] = updated.topP
        }
    }
}
