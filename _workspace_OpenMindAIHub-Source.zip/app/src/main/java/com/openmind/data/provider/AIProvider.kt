package com.openmind.data.provider

import com.openmind.data.model.AIResponse
import com.openmind.data.model.Message
import com.openmind.data.model.ModelInfo
import kotlinx.coroutines.flow.Flow

/**
 * Core abstraction for all AI providers.
 * Every provider (cloud or local) implements this interface.
 * The ProviderManager instantiates the correct implementation based on ProviderConfig.
 */
interface AIProvider {

    /** Unique identifier for this provider instance (from ProviderConfig.id) */
    val id: String

    /** Human-readable name of this provider instance */
    val displayName: String

    /** Whether this provider supports streaming responses */
    val supportsStreaming: Boolean
        get() = true

    /** Whether this provider supports multimodal input (images, files) */
    val supportsMultimodal: Boolean
        get() = false

    /** Whether this provider is a local model (e.g., Ollama) */
    val isLocal: Boolean
        get() = false

    /**
     * Get available models for this provider.
     * @return list of model information
     */
    suspend fun getModelList(): List<ModelInfo>

    /**
     * Send a message and stream the response token-by-token.
     * This is the primary method for chat interactions.
     *
     * @param prompt The user's current message
     * @param context Previous conversation messages for context
     * @param model The model ID to use (null for provider default)
     * @param temperature Sampling temperature (0.0 - 2.0)
     * @param maxTokens Maximum tokens to generate
     * @param systemPrompt Optional system prompt override
     * @return Flow of response parts (tokens) for progressive display
     */
    fun streamCompletion(
        prompt: String,
        context: List<Message>,
        model: String? = null,
        temperature: Float? = null,
        maxTokens: Int? = null,
        systemPrompt: String? = null
    ): Flow<AIResponse.Part>

    /**
     * Send a message and get a complete (non-streaming) response.
     * Default implementation collects the stream and concatenates.
     *
     * @param prompt The user's current message
     * @param context Previous conversation messages for context
     * @param model The model ID to use
     * @param temperature Sampling temperature
     * @param maxTokens Maximum tokens to generate
     * @param systemPrompt Optional system prompt override
     * @return Complete AI response
     */
    suspend fun completeCompletion(
        prompt: String,
        context: List<Message>,
        model: String? = null,
        temperature: Float? = null,
        maxTokens: Int? = null,
        systemPrompt: String? = null
    ): AIResponse {
        val fullText = StringBuilder()
        streamCompletion(prompt, context, model, temperature, maxTokens, systemPrompt)
            .collect { part ->
                if (!part.isFinal) {
                    fullText.append(part.token)
                }
            }
        return AIResponse(fullText = fullText.toString(), model = model, providerId = id)
    }

    /**
     * Test connectivity to this provider.
     * @return true if the provider is reachable and operational
     */
    suspend fun testConnection(): Boolean

    /**
     * Release resources held by this provider.
     * Called when the provider is removed or the app is shutting down.
     */
    fun close()

    /**
     * Cancel any ongoing request.
     * Useful for stopping generation mid-stream.
     */
    fun cancel()
}
