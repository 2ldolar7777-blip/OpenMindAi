package com.openmind.data.db

import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey
import com.openmind.data.model.Message

@Entity(
    tableName = "messages",
    foreignKeys = [
        ForeignKey(
            entity = ConversationEntity::class,
            parentColumns = ["id"],
            childColumns = ["conversationId"],
            onDelete = ForeignKey.CASCADE
        )
    ],
    indices = [
        Index(value = ["conversationId"], name = "index_messages_conversation_id"),
        Index(value = ["timestamp"], name = "index_messages_timestamp"),
        Index(value = ["role"], name = "index_messages_role")
    ]
)
data class MessageEntity(
    @PrimaryKey val id: String,
    val conversationId: String,
    val role: String,
    val content: String,
    val timestamp: Long,
    val providerId: String? = null,
    val modelName: String? = null,
    val tokenCount: Int? = null
) {
    fun toDomain(): Message = Message(
        id = id,
        role = Message.Role.fromValue(role),
        content = content,
        timestamp = timestamp,
        providerId = providerId,
        modelName = modelName,
        tokenCount = tokenCount
    )
}
