package com.openmind.data.provider

import android.util.Log
import com.openmind.data.model.*
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import kotlinx.serialization.json.*
import okhttp3.*
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.RequestBody.Companion.toRequestBody
import java.util.concurrent.TimeUnit

/**
 * Provider for Ollama local LLM runtime.
 * Connects to a local Ollama instance running on the device's network.
 * 
 * Ollama API docs: https://github.com/ollama/ollama/blob/main/docs/api.md
 * 
 * Supports:
 * - Model listing via GET /api/tags
 * - Streaming chat via POST /api/chat (NDJSON streaming)
 * - Non-streaming generation via POST /api/generate
 */
class OllamaProvider(private val cfg: ProviderConfig) : AIProvider {

    companion object {
        private const val TAG = "OllamaProvider"
        private val JSON_MEDIA_TYPE = "application/json; charset=utf-8".toMediaType()
        private val json = Json { ignoreUnknownKeys = true }
    }

    override val id: String = cfg.id
    override val displayName: String = cfg.name
    override val supportsStreaming: Boolean = true
    override val isLocal: Boolean = true

    private val client = OkHttpClient.Builder()
        .connectTimeout(60, TimeUnit.SECONDS)  // Local network may be slower
        .readTimeout(300, TimeUnit.SECONDS)     // LLM inference can be slow
        .writeTimeout(30, TimeUnit.SECONDS)
        .build()

    private var currentCall: Call? = null

    override suspend fun getModelList(): List<ModelInfo> {
        return try {
            val request = Request.Builder()
                .url("${cfg.baseUrl}/api/tags")
                .get()
                .build()

            val response = client.newCall(request).execute()
            val body = response.body?.string() ?: return emptyList()

            if (!response.isSuccessful) {
                Log.e(TAG, "Failed to fetch models: ${response.code}")
                return emptyList()
            }

            val element = Json.parseToJsonElement(body)
            val models = element.jsonObject["models"]?.jsonArray ?: return emptyList()

            models.map { item ->
                val obj = item.jsonObject
                val name = obj["name"]?.jsonPrimitive?.content ?: "unknown"
                val size = obj["size"]?.jsonPrimitive?.longOrNull
                val quantLevel = obj["details"]?.jsonObject?.get("quantization_level")?.jsonPrimitive?.contentOrNull
                
                ModelInfo(
                    id = name,
                    name = name,
                    description = obj["details"]?.jsonObject?.get("family")?.jsonPrimitive?.contentOrNull,
                    contextLength = obj["parameters"]?.jsonPrimitive?.contentOrNull?.let { 
                        // Try to parse context length from parameter string
                        null 
                    },
                    isLocal = true,
                    capabilities = buildList {
                        add("text-generation")
                        if (name.contains("vision") || name.contains("llava")) add("vision")
                    }
                )
            }
        } catch (e: Exception) {
            Log.e(TAG, "Failed to fetch Ollama models", e)
            emptyList()
        }
    }

    override fun streamCompletion(
        prompt: String,
        context: List<Message>,
        model: String?,
        temperature: Float?,
        maxTokens: Int?,
        systemPrompt: String?
    ): Flow<AIResponse.Part> = flow {
        val modelName = model ?: "llama3.2"
        val requestJson = buildChatRequest(prompt, context, modelName, temperature, maxTokens, systemPrompt)

        try {
            val request = Request.Builder()
                .url("${cfg.baseUrl}/api/chat")
                .post(requestJson.toRequestBody(JSON_MEDIA_TYPE))
                .header("Content-Type", "application/json")
                .apply {
                    cfg.apiKey?.let { header("Authorization", "Bearer $it") }
                }
                .build()

            val call = client.newCall(request)
            currentCall = call
            val response = call.execute()

            if (!response.isSuccessful) {
                val errorBody = response.body?.string() ?: "Unknown error"
                emit(AIResponse.Part(token = "Error connecting to Ollama (${response.code}): $errorBody", isFinal = true))
                return@flow
            }

            // Ollama uses NDJSON streaming (one JSON object per line)
            val source = response.body?.source() ?: run {
                emit(AIResponse.Part(token = "Error: Empty response body", isFinal = true))
                return@flow
            }

            while (!source.exhausted()) {
                val line = source.readUtf8Line() ?: break
                if (line.isBlank()) continue

                try {
                    val element = Json.parseToJsonElement(line)
                    val content = element.jsonObject["message"]?.jsonObject?.get("content")?.jsonPrimitive?.content
                    val done = element.jsonObject["done"]?.jsonPrimitive?.booleanOrNull ?: false

                    if (content != null && content.isNotEmpty()) {
                        emit(AIResponse.Part(token = content, isFinal = false))
                    }

                    if (done) {
                        emit(AIResponse.Part(token = "", isFinal = true))
                        break
                    }
                } catch (e: Exception) {
                    Log.w(TAG, "Failed to parse Ollama NDJSON line: $line", e)
                }
            }
        } catch (e: CancellationException) {
            emit(AIResponse.Part(token = "", isFinal = true))
        } catch (e: Exception) {
            Log.e(TAG, "Ollama streaming failed", e)
            val errorMsg = when {
                e.message?.contains("Connection refused") == true -> 
                    "Cannot connect to Ollama. Make sure Ollama is running at ${cfg.baseUrl}"
                e.message?.contains("timeout") == true -> 
                    "Connection to Ollama timed out. The model may be loading..."
                else -> "Error: ${e.message}"
            }
            emit(AIResponse.Part(token = errorMsg, isFinal = true))
        } finally {
            currentCall = null
        }
    }

    override suspend fun testConnection(): Boolean {
        return try {
            val request = Request.Builder()
                .url("${cfg.baseUrl}/api/tags")
                .get()
                .build()
            val response = client.newCall(request).execute()
            response.isSuccessful
        } catch (e: Exception) {
            Log.e(TAG, "Ollama connection test failed", e)
            false
        }
    }

    override fun close() {
        currentCall?.cancel()
        client.dispatcher.executorService.shutdown()
        client.connectionPool.evictAll()
    }

    override fun cancel() {
        currentCall?.cancel()
        currentCall = null
    }

    private fun buildChatRequest(
        prompt: String,
        context: List<Message>,
        model: String,
        temperature: Float?,
        maxTokens: Int?,
        systemPrompt: String?
    ): String {
        val messages = mutableListOf<JsonObject>()

        // System prompt
        systemPrompt?.let {
            messages.add(buildJsonObject {
                put("role", "system")
                put("content", it)
            })
        }

        // Context messages
        context.takeLast(20).forEach { msg ->
            messages.add(buildJsonObject {
                put("role", msg.role.value)
                put("content", msg.content)
            })
        }

        // Current user message
        messages.add(buildJsonObject {
            put("role", "user")
            put("content", prompt)
        })

        return buildJsonObject {
            put("model", model)
            put("messages", JsonArray(messages.map { it }))
            put("stream", true)
            temperature?.let { put("temperature", it.toDouble()) }
            maxTokens?.let { put("num_predict", it) }
        }.toString()
    }
}
