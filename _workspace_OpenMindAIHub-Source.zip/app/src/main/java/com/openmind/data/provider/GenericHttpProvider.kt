package com.openmind.data.provider

import android.util.Log
import com.openmind.data.model.*
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import kotlinx.serialization.json.*
import okhttp3.*
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.RequestBody.Companion.toRequestBody
import java.util.concurrent.TimeUnit

/**
 * Generic HTTP provider that supports any OpenAI-compatible API endpoint.
 * This is the primary provider for cloud services like OpenAI, Anthropic, 
 * Google Gemini, Groq, Mistral, and any other OpenAI-compatible API.
 * 
 * The `meta` JSON field in ProviderConfig can specify custom:
 * - headers: Additional HTTP headers
 * - requestTemplate: Custom request body template
 * - responsePath: JSON path to extract text from response
 * - streamingFormat: SSE format type (openai, anthropic, etc.)
 */
class GenericHttpProvider(private val cfg: ProviderConfig) : AIProvider {

    companion object {
        private const val TAG = "GenericHttpProvider"
        private val JSON_MEDIA_TYPE = "application/json; charset=utf-8".toMediaType()
        private val json = Json { 
            ignoreUnknownKeys = true
            isLenient = true
            encodeDefaults = true
        }
    }

    override val id: String = cfg.id
    override val displayName: String = cfg.name
    override val supportsStreaming: Boolean = true

    private val client = OkHttpClient.Builder()
        .connectTimeout(30, TimeUnit.SECONDS)
        .readTimeout(120, TimeUnit.SECONDS)
        .writeTimeout(30, TimeUnit.SECONDS)
        .build()

    private var currentCall: Call? = null
    private val activeScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    // Parse meta config
    private val metaConfig: MetaConfig by lazy { parseMetaConfig() }

    data class MetaConfig(
        val headers: Map<String, String> = emptyMap(),
        val modelsEndpoint: String = "/v1/models",
        val chatEndpoint: String = "/v1/chat/completions",
        val responseContentPath: String = "choices.0.message.content",
        val streamingFormat: String = "openai", // openai, anthropic, gemini
        val defaultModel: String = "gpt-3.5-turbo",
        val maxContextMessages: Int = 20
    )

    private fun parseMetaConfig(): MetaConfig {
        val meta = cfg.meta ?: return MetaConfig()
        return try {
            val element = Json.parseToJsonElement(meta)
            val obj = element.jsonObject
            MetaConfig(
                headers = obj["headers"]?.jsonObject?.mapValues { it.value.jsonPrimitive.content } ?: emptyMap(),
                modelsEndpoint = obj["modelsEndpoint"]?.jsonPrimitive?.content ?: "/v1/models",
                chatEndpoint = obj["chatEndpoint"]?.jsonPrimitive?.content ?: "/v1/chat/completions",
                responseContentPath = obj["responseContentPath"]?.jsonPrimitive?.content ?: "choices.0.message.content",
                streamingFormat = obj["streamingFormat"]?.jsonPrimitive?.content ?: "openai",
                defaultModel = obj["defaultModel"]?.jsonPrimitive?.content ?: getDefaultModelForType(),
                maxContextMessages = obj["maxContextMessages"]?.jsonPrimitive?.intOrNull ?: 20
            )
        } catch (e: Exception) {
            Log.w(TAG, "Failed to parse meta config, using defaults", e)
            MetaConfig(defaultModel = getDefaultModelForType())
        }
    }

    private fun getDefaultModelForType(): String = when (cfg.type) {
        ProviderConfig.ProviderType.OPENAI -> "gpt-3.5-turbo"
        ProviderConfig.ProviderType.ANTHROPIC -> "claude-3-haiku-20240307"
        ProviderConfig.ProviderType.GEMINI -> "gemini-pro"
        ProviderConfig.ProviderType.GROQ -> "mixtral-8x7b-32768"
        ProviderConfig.ProviderType.MISTRAL -> "mistral-tiny"
        else -> "default"
    }

    override suspend fun getModelList(): List<ModelInfo> {
        return try {
            val request = buildRequest("${cfg.baseUrl}${metaConfig.modelsEndpoint}", "GET")
            val response = client.newCall(request).execute()
            val body = response.body?.string() ?: return emptyList()

            if (!response.isSuccessful) {
                Log.e(TAG, "Model list request failed: ${response.code}")
                return listOf(ModelInfo(metaConfig.defaultModel, metaConfig.defaultModel))
            }

            parseModelListResponse(body)
        } catch (e: Exception) {
            Log.e(TAG, "Failed to fetch model list", e)
            listOf(ModelInfo(metaConfig.defaultModel, metaConfig.defaultModel))
        }
    }

    override fun streamCompletion(
        prompt: String,
        context: List<Message>,
        model: String?,
        temperature: Float?,
        maxTokens: Int?,
        systemPrompt: String?
    ): Flow<AIResponse.Part> = flow {
        val modelName = model ?: metaConfig.defaultModel
        val requestJson = buildChatRequest(prompt, context, modelName, temperature, maxTokens, systemPrompt, stream = true)
        val url = "${cfg.baseUrl}${metaConfig.chatEndpoint}"
        val request = buildRequest(url, "POST", requestJson)

        try {
            val call = client.newCall(request)
            currentCall = call
            val response = call.execute()

            if (!response.isSuccessful) {
                val errorBody = response.body?.string() ?: "Unknown error"
                emit(AIResponse.Part(token = "Error (${response.code}): $errorBody", isFinal = true))
                return@flow
            }

            // Try SSE streaming first
            val contentType = response.header("Content-Type", "")
            if (contentType.contains("text/event-stream") || contentType.contains("application/octet-stream")) {
                parseSSEStream(response) { part ->
                    emit(part)
                }
            } else {
                // Fallback: non-streaming response, emit as tokens
                val body = response.body?.string() ?: ""
                val text = extractContentFromResponse(body)
                emitTokensFromText(text)
            }
        } catch (e: CancellationException) {
            emit(AIResponse.Part(token = "", isFinal = true))
        } catch (e: Exception) {
            Log.e(TAG, "Stream completion failed", e)
            emit(AIResponse.Part(token = "Error: ${e.message}", isFinal = true))
        } finally {
            currentCall = null
        }
    }

    override suspend fun testConnection(): Boolean {
        return try {
            val url = "${cfg.baseUrl}${metaConfig.modelsEndpoint}"
            val request = buildRequest(url, "GET")
            val response = client.newCall(request).execute()
            response.isSuccessful
        } catch (e: Exception) {
            Log.e(TAG, "Connection test failed", e)
            false
        }
    }

    override fun close() {
        activeScope.cancel()
        currentCall?.cancel()
        client.dispatcher.executorService.shutdown()
        client.connectionPool.evictAll()
    }

    override fun cancel() {
        currentCall?.cancel()
        currentCall = null
    }

    // --- Private helpers ---

    private fun buildRequest(url: String, method: String, body: String? = null): Request {
        return Request.Builder()
            .url(url)
            .apply {
                when (method) {
                    "GET" -> get()
                    "POST" -> post(body!!.toRequestBody(JSON_MEDIA_TYPE))
                    "PUT" -> put(body!!.toRequestBody(JSON_MEDIA_TYPE))
                    "DELETE" -> delete(body?.toRequestBody(JSON_MEDIA_TYPE))
                }
                // Auth headers
                cfg.apiKey?.let { key ->
                    when (cfg.type) {
                        ProviderConfig.ProviderType.ANTHROPIC -> {
                            header("x-api-key", key)
                            header("anthropic-version", "2023-06-01")
                        }
                        ProviderConfig.ProviderType.GEMINI -> {
                            // Gemini uses query param, handled in URL
                        }
                        else -> {
                            header("Authorization", "Bearer $key")
                        }
                    }
                }
                // Meta headers
                metaConfig.headers.forEach { (key, value) ->
                    header(key, value)
                }
                header("Accept", "text/event-stream")
                header("Content-Type", "application/json")
            }
            .build()
    }

    private fun buildChatRequest(
        prompt: String,
        context: List<Message>,
        model: String,
        temperature: Float?,
        maxTokens: Int?,
        systemPrompt: String?,
        stream: Boolean
    ): String {
        val messages = mutableListOf<JsonObject>()

        // System prompt
        val sys = systemPrompt ?: "You are a helpful AI assistant."
        messages.add(buildJsonObject {
            put("role", "system")
            put("content", sys)
        })

        // Context messages (limited)
        val recentContext = context.takeLast(metaConfig.maxContextMessages)
        recentContext.forEach { msg ->
            messages.add(buildJsonObject {
                put("role", msg.role.value)
                put("content", msg.content)
            })
        }

        // Current user message
        messages.add(buildJsonObject {
            put("role", "user")
            put("content", prompt)
        })

        return buildJsonObject {
            put("model", model)
            put("messages", JsonArray(messages.map { it }))
            put("stream", stream)
            temperature?.let { put("temperature", it) }
            maxTokens?.let { put("max_tokens", it) }
        }.toString()
    }

    private suspend fun parseSSEStream(response: Response, emitter: (AIResponse.Part) -> Unit) {
        val source = response.body?.source() ?: return

        try {
            val sseParser = SSEParser()
            while (!source.exhausted()) {
                val line = source.readUtf8Line() ?: break
                if (line.isBlank()) continue

                if (line.startsWith("data: ")) {
                    val data = line.removePrefix("data: ").trim()
                    if (data == "[DONE]") {
                        emitter(AIResponse.Part(token = "", isFinal = true))
                        break
                    }

                    try {
                        val jsonElement = Json.parseToJsonElement(data)
                        val content = extractStreamContent(jsonElement)
                        if (content != null && content.isNotEmpty()) {
                            emitter(AIResponse.Part(token = content, isFinal = false))
                        }
                    } catch (e: Exception) {
                        // Skip malformed JSON in stream
                        Log.w(TAG, "Failed to parse SSE data: $data", e)
                    }
                }
            }
        } catch (e: Exception) {
            Log.e(TAG, "SSE stream parsing error", e)
            emitter(AIResponse.Part(token = "", isFinal = true))
        }
    }

    private fun extractStreamContent(element: JsonElement): String? {
        return try {
            val obj = element.jsonObject
            when (metaConfig.streamingFormat) {
                "openai" -> {
                    val choices = obj["choices"]?.jsonArray
                    val delta = choices?.get(0)?.jsonObject?.get("delta")?.jsonObject
                    delta?.get("content")?.jsonPrimitive?.content
                }
                "anthropic" -> {
                    val type = obj["type"]?.jsonPrimitive?.content
                    when (type) {
                        "content_block_delta" -> {
                            obj["delta"]?.jsonObject?.get("text")?.jsonPrimitive?.content
                        }
                        else -> null
                    }
                }
                else -> {
                    // Try OpenAI format as fallback
                    val choices = obj["choices"]?.jsonArray
                    choices?.get(0)?.jsonObject?.get("delta")?.jsonObject?.get("content")?.jsonPrimitive?.content
                }
            }
        } catch (e: Exception) {
            null
        }
    }

    private suspend fun emitTokensFromText(text: String) {
        if (text.isBlank()) {
            emit(AIResponse.Part(token = "", isFinal = true))
            return
        }
        // Split by whitespace for token-by-token display
        val tokens = text.split(Regex("\\s+")).filter { it.isNotBlank() }
        tokens.forEachIndexed { index, token ->
            val withSpace = if (index > 0) " $token" else token
            emit(AIResponse.Part(token = withSpace, isFinal = false))
            delay(20)
        }
        emit(AIResponse.Part(token = "", isFinal = true))
    }

    private fun extractContentFromResponse(body: String): String {
        return try {
            val element = Json.parseToJsonElement(body)
            extractContentByPath(element, metaConfig.responseContentPath)
        } catch (e: Exception) {
            Log.e(TAG, "Failed to extract content from response", e)
            body
        }
    }

    private fun extractContentByPath(element: JsonElement, path: String): String {
        val parts = path.split(".")
        var current: JsonElement = element
        for (part in parts) {
            current = when (current) {
                is JsonObject -> {
                    val key = part.removeSurrounding("\"")
                    current.jsonObject[key] ?: return ""
                }
                is JsonArray -> {
                    val index = part.toIntOrNull() ?: return ""
                    if (index < current.jsonArray.size) current.jsonArray[index] else return ""
                }
                else -> return ""
            }
        }
        return when (current) {
            is JsonPrimitive -> current.content
            else -> current.toString()
        }
    }

    private fun parseModelListResponse(body: String): List<ModelInfo> {
        return try {
            val element = Json.parseToJsonElement(body)
            val data = element.jsonObject["data"]?.jsonArray ?: return emptyList()
            data.map { item ->
                val obj = item.jsonObject
                val id = obj["id"]?.jsonPrimitive?.content ?: "unknown"
                ModelInfo(
                    id = id,
                    name = obj["name"]?.jsonPrimitive?.content ?: id,
                    description = obj["description"]?.jsonPrimitive?.contentOrNull
                )
            }
        } catch (e: Exception) {
            Log.e(TAG, "Failed to parse model list", e)
            emptyList()
        }
    }

    /**
     * Simple SSE line parser
     */
    private class SSEParser {
        private val buffer = StringBuilder()

        fun processLine(line: String): List<String> {
            val events = mutableListOf<String>()
            if (line.isBlank()) {
                if (buffer.isNotEmpty()) {
                    events.add(buffer.toString().trim())
                    buffer.clear()
                }
            } else if (line.startsWith("data: ")) {
                buffer.appendLine(line.removePrefix("data: "))
            }
            return events
        }
    }
}
