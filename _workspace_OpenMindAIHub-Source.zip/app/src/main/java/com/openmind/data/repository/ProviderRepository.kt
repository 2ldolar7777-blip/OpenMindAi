package com.openmind.data.repository

import com.openmind.data.db.ProviderConfigDao
import com.openmind.data.db.toEntity
import com.openmind.data.model.ModelInfo
import com.openmind.data.model.ProviderConfig
import com.openmind.data.provider.ProviderManager
import com.openmind.data.security.SecureKeyStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import java.util.UUID
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Repository for managing AI provider configurations.
 * API keys are stored securely via SecureKeyStore (EncryptedSharedPreferences).
 */
@Singleton
class ProviderRepository @Inject constructor(
    private val providerConfigDao: ProviderConfigDao,
    private val providerManager: ProviderManager,
    private val secureKeyStore: SecureKeyStore
) {

    /**
     * Get all enabled providers as a reactive flow.
     * Injects the API key from secure storage into each config.
     */
    fun getEnabledProviders(): Flow<List<ProviderConfig>> =
        providerManager.listAvailableFlow().map { entities ->
            entities.map { entity ->
                val domain = entity.toDomain()
                domain.copy(apiKey = secureKeyStore.getApiKey(domain.id) ?: domain.apiKey)
            }
        }

    /**
     * Get all providers (including disabled).
     * Injects API keys from secure storage.
     */
    fun getAllProviders(): Flow<List<ProviderConfig>> =
        providerConfigDao.getAllFlow().map { entities ->
            entities.map { entity ->
                val domain = entity.toDomain()
                domain.copy(apiKey = secureKeyStore.getApiKey(domain.id) ?: domain.apiKey)
            }
        }

    /**
     * Get a specific provider by ID.
     */
    suspend fun getProvider(id: String): ProviderConfig? {
        val entity = providerConfigDao.getById(id) ?: return null
        val domain = entity.toDomain()
        return domain.copy(apiKey = secureKeyStore.getApiKey(id) ?: domain.apiKey)
    }

    /**
     * Add a new provider configuration.
     * API key is stored separately in encrypted storage.
     */
    suspend fun addProvider(
        name: String,
        type: ProviderConfig.ProviderType,
        baseUrl: String,
        apiKey: String? = null,
        meta: String? = null,
        isDefault: Boolean = false
    ): ProviderConfig {
        val id = UUID.randomUUID().toString()
        val config = ProviderConfig(
            id = id,
            name = name,
            type = type,
            baseUrl = baseUrl.trimEnd('/'),
            apiKey = null, // Don't store in DB
            meta = meta,
            isDefault = isDefault
        )
        providerConfigDao.insert(config.toEntity())

        // Store API key securely
        if (!apiKey.isNullOrBlank()) {
            secureKeyStore.storeApiKey(id, apiKey)
        }

        // If this is set as default, unset others
        if (isDefault) {
            providerConfigDao.getAll().filter { it.id != id && it.isDefault }.forEach {
                providerConfigDao.setDefault(it.id, false)
            }
        }

        return config
    }

    /**
     * Update an existing provider configuration.
     */
    suspend fun updateProvider(config: ProviderConfig) {
        // Update API key in secure storage
        if (!config.apiKey.isNullOrBlank()) {
            secureKeyStore.storeApiKey(config.id, config.apiKey)
        }
        // Save config without API key to database
        val entity = config.copy(apiKey = null).toEntity().copy(updatedAt = System.currentTimeMillis())
        providerConfigDao.insert(entity)
        providerManager.reloadProvider(config.id)
    }

    /**
     * Delete a provider configuration and its stored API key.
     */
    suspend fun deleteProvider(id: String) {
        providerManager.removeProvider(id)
        secureKeyStore.removeApiKey(id)
        providerConfigDao.deleteById(id)
    }

    /**
     * Enable or disable a provider.
     */
    suspend fun setProviderEnabled(id: String, enabled: Boolean) {
        providerConfigDao.setEnabled(id, enabled)
        if (enabled) {
            providerManager.reloadProvider(id)
        } else {
            providerManager.removeProvider(id)
        }
    }

    /**
     * Set a provider as the default.
     */
    suspend fun setDefaultProvider(id: String) {
        // Unset all defaults first
        providerConfigDao.getAll().filter { it.isDefault }.forEach {
            providerConfigDao.setDefault(it.id, false)
        }
        providerConfigDao.setDefault(id, true)
    }

    /**
     * Get available models for a provider.
     */
    suspend fun getModelsForProvider(providerId: String): List<ModelInfo> =
        providerManager.getModelsForProvider(providerId)

    /**
     * Test connection to a provider.
     */
    suspend fun testConnection(id: String): Boolean =
        providerManager.testProviderConnection(id)

    /**
     * Get the default provider.
     */
    suspend fun getDefaultProvider(): ProviderConfig? {
        val entity = providerConfigDao.getDefault() ?: return null
        val domain = entity.toDomain()
        return domain.copy(apiKey = secureKeyStore.getApiKey(domain.id) ?: domain.apiKey)
    }

    /**
     * Update only the API key for a provider.
     */
    suspend fun updateApiKey(providerId: String, apiKey: String) {
        secureKeyStore.storeApiKey(providerId, apiKey)
    }

    /**
     * Get a masked version of the API key for display.
     */
    fun getMaskedApiKey(providerId: String): String {
        val key = secureKeyStore.getApiKey(providerId)
        return if (key != null) secureKeyStore.maskApiKey(key) else "••••••••"
    }

    /**
     * Ensure at least one mock provider exists (for first launch).
     */
    suspend fun ensureDefaultProvider() {
        val count = providerConfigDao.count()
        if (count == 0) {
            addProvider(
                name = "Mock Provider (Demo)",
                type = ProviderConfig.ProviderType.OPENAI_MOCK,
                baseUrl = "https://mock.local",
                isDefault = true
            )
        }
    }
}
