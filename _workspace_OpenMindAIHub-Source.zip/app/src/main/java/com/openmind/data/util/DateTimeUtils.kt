package com.openmind.data.util

import java.time.Instant
import java.time.LocalDateTime
import java.time.ZoneId
import java.time.format.DateTimeFormatter
import java.time.temporal.ChronoUnit

/**
 * Date and time formatting utilities for the app.
 */

object DateTimeUtils {

    private val timeFormatter = DateTimeFormatter.ofPattern("HH:mm")
    private val dateFormatter = DateTimeFormatter.ofPattern("MMM dd, yyyy")
    private val dateTimeFormatter = DateTimeFormatter.ofPattern("MMM dd, HH:mm")
    private val fullDateTimeFormatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss")

    /**
     * Format a timestamp (millis) into a relative time string.
     * e.g., "just now", "5m ago", "2h ago", "Yesterday", "Jan 15"
     */
    fun formatRelativeTime(timestampMillis: Long): String {
        val now = System.currentTimeMillis()
        val diff = now - timestampMillis

        return when {
            diff < 60_000 -> "just now"
            diff < 3_600_000 -> {
                val minutes = diff / 60_000
                "${minutes}m ago"
            }
            diff < 86_400_000 -> {
                val hours = diff / 3_600_000
                "${hours}h ago"
            }
            diff < 172_800_000 -> "Yesterday"
            diff < 604_800_000 -> {
                val days = diff / 86_400_000
                "${days}d ago"
            }
            else -> {
                val instant = Instant.ofEpochMilli(timestampMillis)
                LocalDateTime.ofInstant(instant, ZoneId.systemDefault())
                    .format(dateFormatter)
            }
        }
    }

    /**
     * Format a timestamp into time string (e.g., "14:30")
     */
    fun formatTime(timestampMillis: Long): String {
        val instant = Instant.ofEpochMilli(timestampMillis)
        return LocalDateTime.ofInstant(instant, ZoneId.systemDefault())
            .format(timeFormatter)
    }

    /**
     * Format a timestamp into date + time (e.g., "Jan 15, 14:30")
     */
    fun formatDateTime(timestampMillis: Long): String {
        val instant = Instant.ofEpochMilli(timestampMillis)
        return LocalDateTime.ofInstant(instant, ZoneId.systemDefault())
            .format(dateTimeFormatter)
    }

    /**
     * Format a timestamp into full date-time (e.g., "2024-01-15 14:30:00")
     */
    fun formatFullDateTime(timestampMillis: Long): String {
        val instant = Instant.ofEpochMilli(timestampMillis)
        return LocalDateTime.ofInstant(instant, ZoneId.systemDefault())
            .format(fullDateTimeFormatter)
    }

    /**
     * Group timestamp into a category for section headers.
     */
    fun getTimestampCategory(timestampMillis: Long): TimeCategory {
        val now = System.currentTimeMillis()
        val diff = now - timestampMillis
        val instant = Instant.ofEpochMilli(timestampMillis)
        val dateTime = LocalDateTime.ofInstant(instant, ZoneId.systemDefault())
        val today = LocalDateTime.ofInstant(Instant.ofEpochMilli(now), ZoneId.systemDefault())

        return when {
            diff < 86_400_000 && dateTime.toLocalDate() == today.toLocalDate() -> TimeCategory.TODAY
            diff < 172_800_000 -> TimeCategory.YESTERDAY
            diff < 604_800_000 -> TimeCategory.THIS_WEEK
            diff < 2_592_000_000 -> TimeCategory.THIS_MONTH
            else -> TimeCategory.OLDER
        }
    }

    /**
     * Calculate the duration between two timestamps in a human-readable format.
     */
    fun formatDuration(startMillis: Long, endMillis: Long): String {
        val seconds = ChronoUnit.SECONDS.between(
            Instant.ofEpochMilli(startMillis),
            Instant.ofEpochMilli(endMillis)
        )
        return when {
            seconds < 60 -> "${seconds}s"
            seconds < 3600 -> "${seconds / 60}m ${seconds % 60}s"
            else -> "${seconds / 3600}h ${(seconds % 3600) / 60}m"
        }
    }
}

enum class TimeCategory {
    TODAY, YESTERDAY, THIS_WEEK, THIS_MONTH, OLDER
}
