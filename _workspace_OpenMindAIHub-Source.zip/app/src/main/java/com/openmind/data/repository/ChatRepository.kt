package com.openmind.data.repository

import android.util.Log
import com.openmind.data.db.ConversationDao
import com.openmind.data.db.ConversationEntity
import com.openmind.data.db.MessageDao
import com.openmind.data.db.MessageEntity
import com.openmind.data.db.toEntity
import com.openmind.data.model.*
import com.openmind.data.provider.ProviderManager
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.*
import java.util.UUID
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Central repository for chat operations.
 * Coordinates between AI providers, database, and the UI layer.
 */
@Singleton
class ChatRepository @Inject constructor(
    private val providerManager: ProviderManager,
    private val conversationDao: ConversationDao,
    private val messageDao: MessageDao
) {
    companion object {
        private const val TAG = "ChatRepository"
    }

    // --- Conversation Operations ---

    /**
     * Create a new conversation.
     */
    suspend fun createConversation(
        title: String? = null,
        providerId: String? = null,
        modelName: String? = null,
        systemPrompt: String? = null
    ): Conversation {
        val conversation = Conversation(
            id = UUID.randomUUID().toString(),
            title = title ?: "New Chat",
            providerId = providerId,
            modelName = modelName,
            systemPrompt = systemPrompt
        )
        conversationDao.insert(conversation.toEntity())
        return conversation
    }

    /**
     * Get all conversations as a reactive flow.
     */
    fun getAllConversations(): Flow<List<Conversation>> =
        conversationDao.getAllFlow().map { entities ->
            entities.map { it.toDomain() }
        }

    /**
     * Get a specific conversation.
     */
    suspend fun getConversation(id: String): Conversation? =
        conversationDao.getById(id)?.toDomain()

    /**
     * Update conversation title.
     */
    suspend fun updateConversationTitle(id: String, title: String) {
        conversationDao.updateTitle(id, title)
    }

    /**
     * Pin/unpin a conversation.
     */
    suspend fun setConversationPinned(id: String, pinned: Boolean) {
        conversationDao.setPinned(id, pinned)
    }

    /**
     * Delete a conversation and all its messages.
     */
    suspend fun deleteConversation(id: String) {
        messageDao.deleteByConversation(id)
        conversationDao.deleteById(id)
    }

    /**
     * Search conversations by title.
     */
    fun searchConversations(query: String): Flow<List<Conversation>> =
        conversationDao.search(query).map { entities ->
            entities.map { it.toDomain() }
        }

    // --- Message Operations ---

    /**
     * Get messages for a conversation as a reactive flow.
     */
    fun getMessages(conversationId: String): Flow<List<Message>> =
        messageDao.getMessagesForConversationFlow(conversationId).map { entities ->
            entities.map { it.toDomain() }
        }

    /**
     * Save a message to the database.
     */
    suspend fun saveMessage(message: Message, conversationId: String) {
        messageDao.insert(message.toEntity(conversationId))
        // Update conversation timestamp and count
        val count = messageDao.getMessageCount(conversationId)
        conversationDao.updateTimestampAndCount(
            conversationId,
            System.currentTimeMillis(),
            count
        )
    }

    /**
     * Update message content (for streaming updates).
     */
    suspend fun updateMessageContent(messageId: String, content: String) {
        messageDao.updateContent(messageId, content)
    }

    // --- Chat Operations ---

    /**
     * Send a message and stream the response.
     * Saves the user message, streams the AI response, and saves the complete response.
     */
    fun sendMessage(
        providerId: String,
        conversationId: String,
        prompt: String,
        model: String? = null,
        temperature: Float? = null,
        maxTokens: Int? = null,
        systemPrompt: String? = null
    ): Flow<AIResponse.Part> = channelFlow {
        // Save user message
        val userMessage = Message(
            role = Message.Role.USER,
            content = prompt,
            providerId = providerId,
            modelName = model
        )
        saveMessage(userMessage, conversationId)

        // Auto-generate title if this is the first message
        val conversation = getConversation(conversationId)
        if (conversation?.title == "New Chat" && conversation.messageCount == 0) {
            val autoTitle = prompt.take(50) + if (prompt.length > 50) "..." else ""
            updateConversationTitle(conversationId, autoTitle)
        }

        // Get conversation history for context
        val history = messageDao.getMessagesForConversation(conversationId)
            .map { it.toDomain() }

        // Get the provider
        val provider = providerManager.getProvider(providerId)
        if (provider == null) {
            send(AIResponse.Part(token = "Error: Provider not found", isFinal = true))
            return@channelFlow
        }

        // Stream the AI response
        val assistantMessage = Message(
            role = Message.Role.ASSISTANT,
            content = "",
            providerId = providerId,
            modelName = model,
            isStreaming = true
        )
        saveMessage(assistantMessage, conversationId)

        val fullResponse = StringBuilder()

        try {
            provider.streamCompletion(
                prompt = prompt,
                context = history,
                model = model,
                temperature = temperature,
                maxTokens = maxTokens,
                systemPrompt = systemPrompt
            ).collect { part ->
                if (!part.isFinal) {
                    fullResponse.append(part.token)
                    send(part)
                }
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error during streaming", e)
            send(AIResponse.Part(token = "\n\nError: ${e.message}", isFinal = false))
        }

        // Save complete assistant response
        updateMessageContent(assistantMessage.id, fullResponse.toString())

        send(AIResponse.Part(token = "", isFinal = true))
    }

    /**
     * Cancel an ongoing generation.
     */
    suspend fun cancelGeneration(providerId: String) {
        providerManager.getProvider(providerId)?.cancel()
    }

    // --- Export/Import ---

    /**
     * Export a conversation as formatted text.
     */
    suspend fun exportConversation(conversationId: String): String {
        val conversation = getConversation(conversationId) ?: return ""
        val messages = messageDao.getMessagesForConversation(conversationId)

        return buildString {
            appendLine("# ${conversation.title}")
            appendLine()
            messages.forEach { msg ->
                val role = when (msg.role) {
                    "user" -> "👤 You"
                    "assistant" -> "🤖 Assistant"
                    "system" -> "⚙️ System"
                    else -> msg.role
                }
                appendLine("### $role")
                appendLine(msg.content)
                appendLine()
            }
        }
    }

    /**
     * Get token count for a conversation.
     */
    suspend fun getTokenCount(conversationId: String): Int? =
        messageDao.getTotalTokens(conversationId)
}
