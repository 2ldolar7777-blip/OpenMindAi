package com.openmind.data.voice

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

/**
 * Voice input manager using Android's built-in SpeechRecognizer.
 *
 * Provides speech-to-text capability for chat input.
 * Falls back gracefully on devices without speech recognition.
 *
 * Note: For production, consider integrating Whisper.cpp or
 * a cloud STT API for better accuracy and language support.
 */
class VoiceInputManager(private val context: Context) {

    sealed class VoiceState {
        data object Idle : VoiceState()
        data object Listening : VoiceState()
        data class Processing(val partialText: String) : VoiceState()
        data class Result(val text: String) : VoiceState()
        data class Error(val message: String) : VoiceState()
    }

    private val _voiceState = MutableStateFlow<VoiceState>(VoiceState.Idle)
    val voiceState: StateFlow<VoiceState> = _voiceState.asStateFlow()

    private var speechRecognizer: SpeechRecognizer? = null

    val isAvailable: Boolean
        get() = SpeechRecognizer.isRecognitionAvailable(context)

    private val recognitionListener = object : RecognitionListener {
        override fun onReadyForSpeech(params: Bundle?) {
            _voiceState.value = VoiceState.Listening
        }

        override fun onBeginningOfSpeech() {
            // No-op
        }

        override fun onRmsChanged(rmsdB: Float) {
            // Could be used for audio level visualization
        }

        override fun onBufferReceived(buffer: ByteArray?) {
            // No-op
        }

        override fun onEndOfSpeech() {
            // Will transition to Processing or Result
        }

        override fun onError(error: Int) {
            val message = when (error) {
                SpeechRecognizer.ERROR_NETWORK -> "Network error"
                SpeechRecognizer.ERROR_NETWORK_TIMEOUT -> "Network timeout"
                SpeechRecognizer.ERROR_AUDIO -> "Audio recording error"
                SpeechRecognizer.ERROR_SERVER -> "Server error"
                SpeechRecognizer.ERROR_CLIENT -> "Client error"
                SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> "No speech detected"
                SpeechRecognizer.ERROR_NO_MATCH -> "No match found"
                SpeechRecognizer.ERROR_RECOGNIZER_BUSY -> "Recognizer busy"
                SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> "Insufficient permissions"
                else -> "Unknown error ($error)"
            }
            _voiceState.value = VoiceState.Error(message)
        }

        override fun onResults(results: Bundle?) {
            val matches = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
            val text = matches?.firstOrNull() ?: ""
            if (text.isNotBlank()) {
                _voiceState.value = VoiceState.Result(text)
            } else {
                _voiceState.value = VoiceState.Error("No speech recognized")
            }
        }

        override fun onPartialResults(partialResults: Bundle?) {
            val matches = partialResults?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
            val text = matches?.firstOrNull() ?: ""
            if (text.isNotBlank()) {
                _voiceState.value = VoiceState.Processing(text)
            }
        }

        override fun onEvent(eventType: Int, params: Bundle?) {
            // No-op
        }
    }

    /**
     * Start listening for voice input.
     * @param language The language for recognition (default: system language)
     */
    fun startListening(language: String? = null) {
        if (!isAvailable) {
            _voiceState.value = VoiceState.Error("Speech recognition not available on this device")
            return
        }

        stopListening() // Clean up any existing recognizer

        speechRecognizer = SpeechRecognizer.createSpeechRecognizer(context).apply {
            setRecognitionListener(recognitionListener)
        }

        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(
                RecognizerIntent.EXTRA_LANGUAGE_MODEL,
                RecognizerIntent.LANGUAGE_MODEL_FREE_FORM
            )
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1)
            language?.let {
                putExtra(RecognizerIntent.EXTRA_LANGUAGE, it)
            }
        }

        try {
            speechRecognizer?.startListening(intent)
        } catch (e: SecurityException) {
            _voiceState.value = VoiceState.Error("Microphone permission not granted")
        } catch (e: Exception) {
            _voiceState.value = VoiceState.Error("Failed to start voice input: ${e.message}")
        }
    }

    /**
     * Stop listening and clean up resources.
     */
    fun stopListening() {
        speechRecognizer?.stopListening()
        speechRecognizer?.destroy()
        speechRecognizer = null
        if (_voiceState.value is VoiceState.Listening || _voiceState.value is VoiceState.Processing) {
            _voiceState.value = VoiceState.Idle
        }
    }

    /**
     * Reset state to idle.
     */
    fun reset() {
        stopListening()
        _voiceState.value = VoiceState.Idle
    }

    /**
     * Release all resources.
     */
    fun release() {
        stopListening()
    }
}
