package com.openmind.data.model

/**
 * User preferences for the application.
 */
data class UserPreferences(
    val themeMode: ThemeMode = ThemeMode.SYSTEM,
    val dynamicColor: Boolean = true,
    val defaultProviderId: String? = null,
    val defaultModel: String? = null,
    val sendWithEnter: Boolean = true,
    val streamResponses: Boolean = true,
    val showTokenCount: Boolean = false,
    val fontSize: FontSize = FontSize.MEDIUM,
    val language: String = "en",
    val backupEnabled: Boolean = false,
    val autoTitle: Boolean = true,
    val maxContextMessages: Int = 20,
    val temperature: Float = 0.7f,
    val maxTokens: Int = 2048,
    val topP: Float = 1.0f
) {
    enum class ThemeMode { LIGHT, DARK, SYSTEM }
    enum class FontSize { SMALL, MEDIUM, LARGE, EXTRA_LARGE }
}
