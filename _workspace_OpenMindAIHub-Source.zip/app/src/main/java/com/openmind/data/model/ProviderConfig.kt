package com.openmind.data.model

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey
import kotlinx.serialization.Serializable

/**
 * Configuration for an AI provider stored in Room database.
 * Each ProviderConfig represents a provider instance that can be
 * dynamically added/modified without rebuilding the app.
 */
@Entity(
    tableName = "provider_configs",
    indices = [Index(value = ["type"])]
)
@Serializable
data class ProviderConfig(
    @PrimaryKey val id: String,
    val name: String,
    val type: ProviderType,
    val baseUrl: String,
    val apiKey: String? = null,
    val meta: String? = null, // JSON string for custom options like headers, model defaults
    val isEnabled: Boolean = true,
    val isDefault: Boolean = false,
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis(),
    val order: Int = 0
) {
    /**
     * Supported provider types.
     * Each type maps to a specific provider implementation.
     */
    enum class ProviderType(val value: String) {
        OPENAI("openai"),
        ANTHROPIC("anthropic"),
        GEMINI("gemini"),
        OLLAMA("ollama"),
        GROQ("groq"),
        MISTRAL("mistral"),
        OPENAI_MOCK("openai-mock"),
        GENERIC("generic");

        companion object {
            fun fromValue(value: String): ProviderType = entries.find { it.value == value }
                ?: GENERIC
        }
    }
}
