package com.openmind.data.model

/**
 * Information about an AI model available from a provider.
 */
data class ModelInfo(
    val id: String,
    val name: String,
    val description: String? = null,
    val contextLength: Int? = null,
    val capabilities: List<String> = emptyList(),
    val isMultimodal: Boolean = false,
    val isLocal: Boolean = false,
    val pricing: Pricing? = null
) {
    data class Pricing(
        val promptPerMillion: Double? = null,
        val completionPerMillion: Double? = null
    )
}
