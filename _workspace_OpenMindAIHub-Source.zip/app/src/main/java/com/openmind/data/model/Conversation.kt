package com.openmind.data.model

import java.util.UUID

/**
 * Domain model representing a conversation.
 */
data class Conversation(
    val id: String = UUID.randomUUID().toString(),
    val title: String? = null,
    val providerId: String? = null,
    val modelName: String? = null,
    val systemPrompt: String? = null,
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis(),
    val messageCount: Int = 0,
    val isPinned: Boolean = false,
    val tags: List<String> = emptyList()
)
