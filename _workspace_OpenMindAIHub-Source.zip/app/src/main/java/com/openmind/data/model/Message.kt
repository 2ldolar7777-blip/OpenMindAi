package com.openmind.data.model

import java.util.UUID

/**
 * Represents a chat message in the conversation.
 * Used as the domain model throughout the application.
 */
data class Message(
    val id: String = UUID.randomUUID().toString(),
    val role: Role,
    val content: String,
    val timestamp: Long = System.currentTimeMillis(),
    val providerId: String? = null,
    val modelName: String? = null,
    val tokenCount: Int? = null,
    val isStreaming: Boolean = false
) {
    enum class Role(val value: String) {
        USER("user"),
        ASSISTANT("assistant"),
        SYSTEM("system");

        companion object {
            fun fromValue(value: String): Role = entries.find { it.value == value }
                ?: throw IllegalArgumentException("Unknown role: $value")
        }
    }

    fun toEntity(conversationId: String): MessageEntity = MessageEntity(
        id = id,
        conversationId = conversationId,
        role = role.value,
        content = content,
        timestamp = timestamp,
        providerId = providerId,
        modelName = modelName,
        tokenCount = tokenCount
    )
}
