# OpenMind AI Hub ProGuard Rules

# General Android
-keepattributes SourceFile,LineNumberTable
-renamesourcefileattribute SourceFile

# Kotlin
-keep class kotlin.** { *; }
-keep class kotlin.Metadata { *; }
-dontwarn kotlin.**
-keepclassmembers class **$WhenMappings {
    <fields>;
}

# Coroutines
-keepnames class kotlinx.coroutines.internal.MainDispatcherFactory {}
-keepnames class kotlinx.coroutines.CoroutineExceptionHandler {}
-keepclassmembernames class kotlinx.** {
    volatile <fields>;
}
-dontwarn kotlinx.coroutines.**

# Kotlinx Serialization
-keepattributes *Annotation*, InnerClasses
-dontnote kotlinx.serialization.AnnotationsKt
-keepclassmembers class kotlinx.serialization.json.** {
    *** Companion;
    *** Serializers;
    *** serializer(...);
}
-keep,includedescriptorclasses class com.openmind.**$$serializer { *; }
-keepclassmembers class com.openmind.** {
    *** Companion;
    *** serializer(...);
}
-keep,includedescriptorclasses class kotlinx.serialization.serializers.SerializableSerializer
-keep class kotlinx.serialization.serializers.** { *; }
-dontwarn kotlinx.serialization.**

# OkHttp
-dontwarn okhttp3.**
-dontwarn okio.**
-keep class okhttp3.** { *; }
-keep interface okhttp3.** { *; }

# Retrofit
-keep,allowobfuscation,allowshrinking class com.openmind.data.model.**
-keepclassmembers,allowobfuscation class * {
  @retrofit2.http.* <methods>;
}

# Room
-keep class * extends androidx.room.RoomDatabase
-keep @androidx.room.Entity class *
-dontwarn androidx.room.paging.**

# Hilt
-dontwarn dagger.hilt.**
-keep class dagger.hilt.** { *; }
-keep class javax.inject.** { *; }
-keep class * extends dagger.hilt.android.internal.managers.ViewComponentManager$FragmentContextWrapper

# Compose
-dontwarn androidx.compose.**
-keep class androidx.compose.** { *; }
